# Rê Importados — TCC

## O que mudou nesta versão

### 1. Organização de pastas
Antes, tudo (HTML, CSS, JS, PHP e imagens) estava solto numa única pasta.
Agora:

```
ReImportados/
├── inicio.html              ← página inicial (entrada do site)
├── assets/
│   ├── css/                 ← todos os .css
│   ├── js/                  ← todos os .js
│   └── img/                 ← todas as imagens
├── pages/
│   ├── login.html
│   ├── cadastro.html
│   ├── carrinho.html
│   ├── finalizarcompra.html
│   ├── ajuda.html
│   └── estoqueadmin.html    ← painel administrativo
├── backend/
│   ├── config/conexao.php   ← conexão PDO com o banco
│   ├── api/                 ← endpoints PHP (login, cadastro, carrinho, pedido, sessão, logout)
│   └── database/schema.sql  ← script para criar o banco e as tabelas
└── README.md
```

### 2. Fluxo de navegação corrigido
- **Carrinho → Checkout**: antes, o botão "Finalizar Compra" do carrinho só
  mostrava um alerta e voltava para a home — a tela de checkout nunca era
  visitada. Agora ele leva de verdade para `finalizarcompra.html`.
- **Checkout**: antes tinha produtos fixos (`produto1.png`, `produto2.png`,
  que nem existiam) e o botão "voltar" não fazia nada. Agora ele mostra os
  itens reais do carrinho do usuário logado e o botão "voltar" retorna ao
  carrinho.
- **Painel administrativo**: antes nenhuma página linkava para ele e todos
  os links do menu lateral eram `#`. Agora: há um link discreto no rodapé da
  home ("Área administrativa"), o menu tem "Voltar à loja" e "Sair", os
  itens já implementados (Dashboard/Estoque) rolam até a seção certa, e os
  ainda não implementados avisam "em desenvolvimento" em vez de ficar
  mudos. O acesso à página exige login como administrador.
- **ajuda.js**: havia uma tag HTML colada por engano no meio do arquivo
  JavaScript, o que quebrava o script inteiro (nenhuma função funcionava).
  Foi removida.

### 3. Backend conectado de verdade
Antes, `login.php`, `cadastro.php` e `carrinho.php` existiam mas não eram
chamados por nenhuma página (o site era 100% simulado com `localStorage`),
e ainda apontavam para caminhos que não existiam (`includes/conexao.php`,
`index.php`). Agora:

- Login e cadastro salvam e consultam usuários reais no MySQL (com senha
  criptografada via `password_hash`/`password_verify`, e consultas
  parametrizadas via PDO para evitar SQL Injection).
- O carrinho é salvo por usuário no banco (tabela `carrinho`), não mais no
  navegador — some ao trocar de computador antes, agora não.
- Finalizar a compra grava um pedido de verdade (`pedidos` +
  `pedido_itens`) e limpa o carrinho.
- O painel admin exige login com uma conta marcada como administrador.

**O que continua sendo estático (por escolha, para não estourar o
escopo):** os números do dashboard do painel admin (gráficos, "Total de
Produtos: 892" etc.) ainda são dados de exemplo/mockados — não vêm do
banco. O catálogo de produtos da home também continua fixo no HTML (só o
carrinho/pedido é que agora é real).

---

## Como rodar localmente (XAMPP, WAMP ou similar)

1. Instale um pacote com Apache + PHP + MySQL (ex.: XAMPP).
2. Copie a pasta `ReImportados` inteira para dentro de `htdocs` (XAMPP) ou
   `www` (WAMP).
3. Abra o phpMyAdmin (ou o cliente MySQL de sua preferência) e importe
   `backend/database/schema.sql`. Isso cria o banco `re_importados`, as
   tabelas e alguns produtos/um usuário admin de exemplo.

   > **Já tinha o banco na versão 2.0?** Não precisa apagar os dados.
   > Rode `backend/database/migracao_v3.sql` para adicionar as novas
   > colunas sem perder o que já está cadastrado.
4. Confira `backend/config/conexao.php` — se seu MySQL usa usuário/senha
   diferentes de `root`/(vazia), ajuste ali.
5. Acesse `http://localhost/ReImportados/inicio.html` pelo navegador.

**Login de administrador de teste** (criado pelo `schema.sql`):
- E-mail: `admin@reimportados.com`
- Senha: `admin123`

Troque essa senha (ou apague o usuário de teste) antes de usar em
produção.

Para promover outro usuário (cadastrado pelo site) a administrador, rode
no banco:
```sql
UPDATE usuarios SET admin = 1 WHERE email = 'seu-email@exemplo.com';
```

## Observação importante
Este pacote foi revisado e organizado, mas o PHP/MySQL não pôde ser
testado em execução real neste momento (o ambiente usado para a revisão
não tem PHP/MySQL instalados) — o código foi escrito com cuidado e
seguindo boas práticas (PDO, prepared statements, password_hash), mas
vale testar localmente e avisar se algo não se comportar como esperado.
