-- ============================================================
-- Migração v2 -> v3 (Re Importados)
-- Rode este script apenas se JÁ tinha o banco na versão 2.0.
-- Para instalação limpa, use schema.sql (já está na v3).
-- Pode ser executado várias vezes (idempotente).
-- ============================================================

USE re_importados;

-- ---- produtos ------------
ALTER TABLE produtos
    ADD COLUMN IF NOT EXISTS estoque_min INT NOT NULL DEFAULT 5 AFTER estoque,
    ADD COLUMN IF NOT EXISTS ativo TINYINT(1) NOT NULL DEFAULT 1 AFTER estoque_min,
    ADD COLUMN IF NOT EXISTS criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER ativo;

ALTER TABLE produtos
    ADD INDEX IF NOT EXISTS idx_categoria (categoria),
    ADD INDEX IF NOT EXISTS idx_estoque (estoque),
    ADD INDEX IF NOT EXISTS idx_ativo (ativo);

-- ---- carrinho ------------
ALTER TABLE carrinho
    ADD COLUMN IF NOT EXISTS criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER quantidade;

-- ---- pedidos ------------
ALTER TABLE pedidos
    ADD COLUMN IF NOT EXISTS endereco_id INT DEFAULT NULL AFTER usuario_id,
    ADD COLUMN IF NOT EXISTS subtotal DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER endereco_id,
    ADD COLUMN IF NOT EXISTS frete DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER subtotal,
    ADD COLUMN IF NOT EXISTS pagamento_tipo VARCHAR(50) DEFAULT NULL AFTER forma_pagamento,
    ADD COLUMN IF NOT EXISTS parcelas INT DEFAULT NULL AFTER pagamento_tipo,
    ADD COLUMN IF NOT EXISTS itens_carrinho INT NOT NULL DEFAULT 0 AFTER parcelas,
    ADD COLUMN IF NOT EXISTS atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER criado_em;

-- Sempre re-aplica a FK de endereco (segura mesmo se já existir? Use try via procedimento não é
-- suportado em todos os MySQL; abaixo usamos uma checagem idempotente via INFORMATION_SCHEMA).
SET @fk_exists := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
                  WHERE CONSTRAINT_SCHEMA = DATABASE()
                    AND TABLE_NAME = 'pedidos'
                    AND CONSTRAINT_NAME = 'fk_pedidos_endereco');

SET @sql_fk := IF(@fk_exists = 0,
    'ALTER TABLE pedidos ADD CONSTRAINT fk_pedidos_endereco FOREIGN KEY (endereco_id) REFERENCES enderecos(id) ON DELETE SET NULL',
    'SELECT 1');
PREPARE stmt_fk FROM @sql_fk;
EXECUTE stmt_fk;
DEALLOCATE PREPARE stmt_fk;

ALTER TABLE pedidos
    ADD INDEX IF NOT EXISTS idx_status (status),
    ADD INDEX IF NOT EXISTS idx_usuario (usuario_id),
    ADD INDEX IF NOT EXISTS idx_criado_em (criado_em);

-- ============================================================
-- Fim da migração
-- ============================================================
