-- ============================================================
-- Migração v3 -> v4 (Re Importados)
-- Rode este script apenas se JÁ tinha o banco na versão 3.0.
-- Para instalação limpa, use schema.sql (já está na v4).
-- Pode ser executado várias vezes (idempotente).
--
-- MUDANÇAS:
--  * enderecos.cpf            -> CPF do cliente no endereço de entrega
--  * codigos_verificacao      -> tabela de códigos de verificação de email
-- ============================================================

USE re_importados;

-- ---- enderecos (adiciona cpf se ainda não existir) ------------
SET @cpf_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE()
                     AND TABLE_NAME = 'enderecos'
                     AND COLUMN_NAME = 'cpf');

SET @sql_cpf := IF(@cpf_exists = 0,
    'ALTER TABLE enderecos ADD COLUMN cpf VARCHAR(14) NOT NULL DEFAULT '''' AFTER usuario_id',
    'SELECT 1');
PREPARE stmt_cpf FROM @sql_cpf;
EXECUTE stmt_cpf;
DEALLOCATE PREPARE stmt_cpf;

-- ---- codigos_verificacao ------------
CREATE TABLE IF NOT EXISTS codigos_verificacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    codigo VARCHAR(6) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expira_em DATETIME NOT NULL,
    utilizado TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ============================================================
-- Fim da migração
-- ============================================================