-- ============================================================
-- Banco de dados: Re Importados
-- Versão: 3.0 (02/09/2026)
-- Como usar: importe este arquivo no phpMyAdmin (WAMP/XAMPP)
-- ou rode: mysql -u root -p < schema.sql
--
-- MUDANÇAS DA V2 -> V3:
--  * produtos.ativo        -> permite desativar produto sem apagar o histórico
--  * produtos.criado_em    -> data de cadastro do produto
--  * produtos.estoque_min  -> nível mínimo de estoque (alerta de reposição)
--  * carrinho.criado_em    -> registra quando o item foi adicionado
--  * pedidos.endereco_id   -> FK para o endereço de entrega usado no pedido
--  * pedidos.frete         -> custo de frete aplicado no pedido
--  * pedidos.subtotal      -> valor dos produtos (antes do frete)
--  * pedidos.pagamento_tipo-> detalhe do pagamento (ex.: 'credit 3x', 'pix', 'boleto')
--  * pedidos.parcelas      -> nº de parcelas (crédito) ou NULL
--  * pedidos.atualizado_em -> última alteração de status
--  * pedidos.itens_carrinho-> nº de itens (linhas) no pedido
-- ============================================================

CREATE DATABASE IF NOT EXISTS re_importados CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE re_importados;

-- --------------------------------------------------------
-- Usuários (clientes e administradores)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    admin TINYINT(1) NOT NULL DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------
-- Produtos (catálogo da loja)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(200) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    imagem VARCHAR(255),
    categoria VARCHAR(100),
    estoque INT NOT NULL DEFAULT 0,
    estoque_min INT NOT NULL DEFAULT 5,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_categoria (categoria),
    INDEX idx_estoque (estoque),
    INDEX idx_ativo (ativo)
);

-- --------------------------------------------------------
-- Carrinho (um item por usuário+produto; quantidade acumula)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS carrinho (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_usuario_produto (usuario_id, produto_id)
);

-- --------------------------------------------------------
-- Endereços (múltiplos endereços por usuário)
-- (definido antes de pedidos, pois pedidos referencia enderecos)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS enderecos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    rua VARCHAR(200) NOT NULL,
    numero VARCHAR(20) NOT NULL,
    complemento VARCHAR(100) DEFAULT '',
    cidade VARCHAR(100) NOT NULL,
    uf CHAR(2) NOT NULL,
    bairro VARCHAR(100) DEFAULT '',
    padrao TINYINT(1) NOT NULL DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela para códigos de verificação de email
CREATE TABLE IF NOT EXISTS codigos_verificacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    codigo VARCHAR(6) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expira_em DATETIME NOT NULL,
    utilizado TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- --------------------------------------------------------
-- Pedidos
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    endereco_id INT DEFAULT NULL,
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    frete DECIMAL(10,2) NOT NULL DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    forma_pagamento VARCHAR(50),
    pagamento_tipo VARCHAR(50) DEFAULT NULL,
    parcelas INT DEFAULT NULL,
    itens_carrinho INT NOT NULL DEFAULT 0,
    status VARCHAR(50) DEFAULT 'confirmado',
    notas TEXT DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (endereco_id) REFERENCES enderecos(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_usuario (usuario_id),
    INDEX idx_criado_em (criado_em)
);

-- --------------------------------------------------------
-- Itens do pedido
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS pedido_itens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
);

-- --------------------------------------------------------
-- Produtos de exemplo
-- IDs 1-10: Produtos em Alta + Cabelos
-- IDs 11-12: Perfumes
-- IDs 13-15: Makes (Maquiagem)
-- IDs 16-18: Cuidados Pessoais
-- --------------------------------------------------------
INSERT INTO produtos (id, nome, preco, imagem, categoria, estoque) VALUES
(1,  'Kit Hidratante/Body Splash Pokoloka', 169.99, 'bodysplashpokoloka.png', 'Perfumaria', 50),
(2,  'Coconut Passion Victoria''s Secret Body Splash/Creme', 329.99, 'vicsecret.png', 'Perfumaria', 30),
(3,  'Sérum Payot Complexo Vitamina C', 109.99, 'payot.webp', 'Cuidados Pessoais', 40),
(4,  'Corretivo + Líquido Fair Océane Edition', 119.90, 'oceane.webp', 'Maquiagem', 25),
(5,  'Óleo Capilar Wella Professionals Oil Reflections 30ml', 79.99, 'wellaoelo.webp', 'Cabelos', 60),
(6,  'Shampoo Wella Invigo Nutri-Enrich 250ml', 89.99, 'wella-shampoo.webp', 'Cabelos', 60),
(7,  'Máscara Wella Professionals Fusion 150ml', 119.99, 'mascarawella.jpg', 'Cabelos', 45),
(8,  'Condicionador Wella Invigo Color Brilliance 200ml', 84.99, 'condicionadorr.webp', 'Cabelos', 45),
(9,  'Kit Wella Professionals Ultimate Repair', 229.99, 'kitwel.jpg', 'Cabelos', 20),
(10, 'Leave In Wella Nutricurls 150ml', 94.99, 'leavewel.webp', 'Cabelos', 35),
(11, 'Body Splash Pokoloka Gold Edition 250ml', 89.99, 'bodysplashpokoloka.png', 'Perfumaria', 40),
(12, 'Body Mist Victoria''s Secret Pure Seduction 250ml', 179.99, 'vicsecret.png', 'Perfumaria', 35),
(13, 'Base Líquida Océane Camuflagem FPS 30', 89.90, 'oceane.webp', 'Maquiagem', 30),
(14, 'Blush Compacto Payot Trio Sunset Glow', 99.99, 'payot.webp', 'Maquiagem', 25),
(15, 'Máscara de Cílios Océane Volume Extreme', 69.90, 'oceane.webp', 'Maquiagem', 40),
(16, 'Creme Hidratante Payot Hydra 24H 50ml', 129.99, 'payot.webp', 'Cuidados Pessoais', 35),
(17, 'Protetor Solar Payot Sunny Side FPS 50', 139.99, 'payot.webp', 'Cuidados Pessoais', 30),
(18, 'Máscara de Limpeza Payot Pâte Grise', 109.99, 'payot.webp', 'Cuidados Pessoais', 25)
ON DUPLICATE KEY UPDATE nome = VALUES(nome);

-- --------------------------------------------------------
-- Usuário administrador de exemplo
-- Login: admin@reimportados.com   Senha: admin123
-- --------------------------------------------------------
INSERT INTO usuarios (nome, email, senha, admin) VALUES
('Renata Gonçalves', 'admin@reimportados.com',
 '$2y$10$lM/nZzxBzZIZKQI/7oAnmuNav6vyKXz7UrMo2K1Osv.QYl3S02H02', 1)
ON DUPLICATE KEY UPDATE nome = VALUES(nome);
