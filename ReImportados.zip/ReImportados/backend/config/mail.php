<?php
// ============================================================
// config/mail.php — Envio de e-mail real via SMTP do Gmail
// ============================================================
// PASSO A PASSO (fazer UMA vez):
//
// 1) No Gmail que vai ENVIAR os e-mails, ative a verificação
//    em duas etapas:
//    https://myaccount.google.com/security  ->  "Verificação em 2 etapas"
//
// 2) Depois crie uma "Senha de app":
//    https://myaccount.google.com/apppasswords
//    Escolha  "E-mail" -> "Outro (Personalizado)" -> nome "Re Importados"
//    -> o Gmail gera uma senha de 16 letras (ex.: abcd efgh ijkl mnop)
//
// 3) Cole essa senha (SEM espaços) em SMTP_PASSWORD abaixo.
//    A senha de app NÃO é a senha normal da conta.
//
// Se SMTP_PASSWORD estiver vazio, o sistema volta ao modo
// desenvolvimento (código aparece na tela) sem gerar erro.
// ============================================================

define('SMTP_HOST',     'smtp.gmail.com');
define('SMTP_PORT',     587);
define('SMTP_SECURE',   'tls');
define('SMTP_USERNAME', 'luizrdserra@gmail.com');   // conta que ENVIA
define('SMTP_PASSWORD', 'cuqskjpbtfofciyi');         // Senha de App (16 letras)
define('SMTP_FROM',     'luizrdserra@gmail.com');   // remetente (pode ser igual à conta)
define('SMTP_FROM_NAME','Rê Importados');