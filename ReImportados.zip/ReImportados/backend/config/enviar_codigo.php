<?php
// ============================================================
// config/enviar_codigo.php — Envia o e-mail com o código de verificação
// Usado por login.php e verificar_email.php.
// Se o SMTP não estiver configurado (smTP_SENHA vazio), retorna false
// e o sistema mostra o código na tela (modo desenvolvimento).
// ============================================================
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/../vendor/phpmailer/Exception.php';
require_once __DIR__ . '/../vendor/phpmailer/PHPMailer.php';
require_once __DIR__ . '/../vendor/phpmailer/SMTP.php';

function enviarCodigoEmail($email, $codigo, $nome) {
    // Sem senha de app configurada -> modo desenvolvimento: o sistema
    // mostra o código na tela (verificacao.html) em vez de enviar.
    if (SMTP_PASSWORD === '') {
        return false;
    }

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';
        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mail->addAddress($email, $nome);
        $mail->Subject = 'Seu código de acesso - Rê Importados';
        $mail->Body    = "Olá, {$nome}!\n\n"
                       . "Seu código de verificação é: {$codigo}\n"
                       . "Ele expira em 15 minutos.\n\n"
                       . "Caso não tenha feito login, ignore este e-mail.\n"
                       . "— Rê Importados";
        $mail->send();
        return true;
    } catch (Exception $e) {
        // Falha no envio (senha errada, conta bloqueada, rede...) -> volta
        // ao modo desenvolvimento (o código aparece na tela).
        error_log('Falha ao enviar código de verificação: ' . $mail->ErrorInfo);
        return false;
    }
}