<?php

// ============================================================
// conexao.php — Conexão com o banco de dados (arquivo central)
// Todos os endpoints (API) usam este arquivo via require_once.
// == Como funciona ==
//  * Cria uma conexão PDO (PDO = extensão do PHP para MySQL).
//  * Usa a técnica de "prepared statements" (consultas com ?) para
//    blindar o código contra SQL Injection.
//  * Se o banco estiver fora do ar, devolve um JSON de erro ao
//    frontend em vez de estourar uma exceção visível ao usuário.
// ============================================================

// Credenciais de acesso ao MySQL (ajuste conforme seu ambiente)
$host = 'localhost';
$port = '3308';
$banco = 're_importados';
$usuario = 'root';
$senha = 'mysqlfatec';

try {
    // utf8mb4 garante que acentos e emojis sejam salvos corretamente
    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$banco};charset=utf8mb4",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,      // lança exceção em erro SQL (facilita debugar)
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // retorna resultados como array associativo
        ]
    );
} catch (PDOException $erro) {
    // Resposta padronizada de erro sem expor detalhes internos do banco
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro de conexão com o banco de dados.',
    ]);
    exit;
}
?>