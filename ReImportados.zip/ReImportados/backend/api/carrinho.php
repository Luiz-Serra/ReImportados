<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

// ============================================================
// carrinho.php — Carrinho de compras (salvo no BANCO por usuário)
// GET    -> lista os itens do carrinho do usuário logado
// POST   -> adiciona um produto (soma +1 se já existir)
// PUT    -> altera a quantidade (remove se <= 0)
// DELETE -> remove o item
// == Segurança / Regra de negócio ==
//  * Exige login: só funciona se houver sessão (usuario_id).
//  * Não permite adicionar mais itens do que o estoque disponível.
// ============================================================

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'É necessário fazer login para usar o carrinho.']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];
$metodo = $_SERVER['REQUEST_METHOD'];

// ---------------------------------------------------------
// GET: lista os itens do carrinho do usuário logado
// (JOIN junta os itens do carrinho com os dados do produto)
// ---------------------------------------------------------
if ($metodo === 'GET') {
    $stmt = $pdo->prepare(
        "SELECT c.produto_id, c.quantidade, p.nome, p.preco, p.imagem
         FROM carrinho c
         JOIN produtos p ON p.id = c.produto_id
         WHERE c.usuario_id = ?
         ORDER BY c.id"
    );
    $stmt->execute([$usuarioId]);
    echo json_encode(['sucesso' => true, 'itens' => $stmt->fetchAll()]);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true) ?? [];

// ---------------------------------------------------------
// POST: adiciona um produto (ou soma +1 se já existir)
// ---------------------------------------------------------
if ($metodo === 'POST') {
    $produtoId = (int) ($dados['produto_id'] ?? 0);

    if ($produtoId <= 0) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Produto inválido.']);
        exit;
    }

    // Verifica estoque disponível e se o produto está ativo
    $stmtP = $pdo->prepare("SELECT estoque, ativo FROM produtos WHERE id = ?");
    $stmtP->execute([$produtoId]);
    $produto = $stmtP->fetch();
    if (!$produto || !$produto['ativo']) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Produto indisponível.']);
        exit;
    }

    // Total que já está no carrinho deste produto
    $stmtJ = $pdo->prepare("SELECT SUM(quantidade) AS q FROM carrinho WHERE usuario_id = ? AND produto_id = ?");
    $stmtJ->execute([$usuarioId, $produtoId]);
    $jaNoCarrinho = (int)($stmtJ->fetch()['q'] ?? 0);

    // Regra: não deixar o usuário colocar mais do que existe em estoque
    if ($jaNoCarrinho + 1 > $produto['estoque']) {
        http_response_code(400);
        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Estoque insuficiente para este produto. Disponível: ' . $produto['estoque'] . '.',
        ]);
        exit;
    }

    // ON DUPLICATE KEY: se o produto já está no carrinho, soma 1 à quantidade
    $stmt = $pdo->prepare(
        "INSERT INTO carrinho (usuario_id, produto_id, quantidade)
         VALUES (?, ?, 1)
         ON DUPLICATE KEY UPDATE quantidade = quantidade + 1"
    );
    $stmt->execute([$usuarioId, $produtoId]);
    echo json_encode(['sucesso' => true]);
    exit;
}

// ---------------------------------------------------------
// PUT: atualiza a quantidade de um item (remove se <= 0)
// ---------------------------------------------------------
if ($metodo === 'PUT') {
    $produtoId = (int) ($dados['produto_id'] ?? 0);
    $quantidade = (int) ($dados['quantidade'] ?? 0);

    if ($quantidade <= 0) {
        // Quantidade menor/igual a zero = remover o item do carrinho
        $stmt = $pdo->prepare("DELETE FROM carrinho WHERE usuario_id = ? AND produto_id = ?");
        $stmt->execute([$usuarioId, $produtoId]);
    } else {
        // Valida contra o estoque disponível (mesmo ao aumentar no carrinho)
        $stmtP = $pdo->prepare("SELECT estoque FROM produtos WHERE id = ?");
        $stmtP->execute([$produtoId]);
        $produto = $stmtP->fetch();
        if (!$produto || $quantidade > $produto['estoque']) {
            http_response_code(400);
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Estoque insuficiente. Disponível: ' . ($produto ? $produto['estoque'] : 0) . '.',
            ]);
            exit;
        }
        $stmt = $pdo->prepare(
            "UPDATE carrinho SET quantidade = ? WHERE usuario_id = ? AND produto_id = ?"
        );
        $stmt->execute([$quantidade, $usuarioId, $produtoId]);
    }
    echo json_encode(['sucesso' => true]);
    exit;
}

// ---------------------------------------------------------
// DELETE: remove um item do carrinho
// ---------------------------------------------------------
if ($metodo === 'DELETE') {
    $produtoId = (int) ($dados['produto_id'] ?? 0);
    $stmt = $pdo->prepare("DELETE FROM carrinho WHERE usuario_id = ? AND produto_id = ?");
    $stmt->execute([$usuarioId, $produtoId]);
    echo json_encode(['sucesso' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['sucesso' => false, 'mensagem' => 'Método não suportado.']);
exit;
