<?php
session_start();                     // início da sessão (guarda quem está logado)
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';   // $pdo
require_once __DIR__ . '/../config/enviar_codigo.php'; // vs enviarCodigoEmail()

// ============================================================
// login.php — Autentica o usuário e cria a sessão
// Recebe JSON: { "email", "senha" }
// == Segurança ==
//  * Busca o hash no banco e confere com password_verify
//    (a senha nunca é comparada como texto puro).
//  * session_regenerate_id evita "session fixation" (sequestro de sessão).
// ============================================================

$dados = json_decode(file_get_contents('php://input'), true) ?? [];

$email = trim($dados['email'] ?? '');
$senha = $dados['senha'] ?? '';

if ($email === '' || $senha === '') {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Preencha e-mail e senha.']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, nome, senha, admin FROM usuarios WHERE email = ?");
$stmt->execute([$email]);
$usuario = $stmt->fetch();

if ($usuario && password_verify($senha, $usuario['senha'])) {

    // Cliente (não-admin): exige verificação de e-mail em tempo real.
    // Gera um código de 6 dígitos, salva no banco e envia por e-mail
    // (o Gmail costuma entregar na caixa de Spam).
    if (!$usuario['admin']) {
        $codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiraEm = date('Y-m-d H:i:s', time() + 900); // válido por 15 minutos

        $stmt = $pdo->prepare("INSERT INTO codigos_verificacao (usuario_id, codigo, expira_em) VALUES (?, ?, ?)");
        $stmt->execute([$usuario['id'], $codigo, $expiraEm]);

        $emailEnviado = enviarCodigoEmail($email, $codigo, $usuario['nome']);

        // Guarda o e-mail pendente para a tela de verificação confirmar
        $_SESSION['email_pendente'] = $email;

        echo json_encode([
            'sucesso' => true,
            'precisa_verificacao' => true,
            'nome' => $usuario['nome'],
            'email' => $email,
            'email_enviado' => $emailEnviado,
            // Modo desenvolvimento: se o e-mail não pôde ser enviado
            // (WAMP sem sendmail configurado), o código aparece na tela.
            'dev_codigo' => $emailEnviado ? null : $codigo,
        ]);
        exit;
    }

    // Gera um novo ID de sessão a cada login (proteção contra session fixation)
    session_regenerate_id(true);

    // Guarda na sessão as informações do usuário logado (usadas por todo o sistema)
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['nome'] = $usuario['nome'];
    $_SESSION['admin'] = (bool) $usuario['admin'];

    echo json_encode([
        'sucesso' => true,
        'nome' => $usuario['nome'],
        'admin' => (bool) $usuario['admin'], // informa se é admin (para redirecionar ao painel)
    ]);
    exit;
} else {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'E-mail ou senha inválidos.']);
}
