<?php
// ============================================================
// sessao.php — Verifica se o usuário está logado
// Consulta a sessão PHP (criada no login) e informa o frontend.
// Sempre que uma página carrega, este endpoint é chamado para
// saber se mostra "Entrar" ou "Sair" no menu.
// ============================================================
session_start();
header('Content-Type: application/json; charset=utf-8');

if (isset($_SESSION['usuario_id'])) {
    echo json_encode([
        'logado' => true, // há um usuário na sessão
        'nome' => $_SESSION['nome'],
        'admin' => $_SESSION['admin'] ?? false, // usado para liberar o painel admin
    ]);
} else {
    echo json_encode(['logado' => false]);
    exit;
}
