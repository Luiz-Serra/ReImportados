<?php
session_start(); // atividade: vínculo com o PHP
header('Content-Type: application/json; charset=utf-8'); // padrão das respostas da API
require_once __DIR__ . '/../config/conexao.php'; // carrega o PDO ($pdo)

// ============================================================
// cadastro.php — Cria a conta de um novo cliente
// Recebe JSON: { "nome", "email", "senha" }
// == Segurança ==
//  * Valida e-mail com FILTER_VALIDATE_EMAIL.
//  * Define tamanho mínimo de senha.
//  * Usa password_hash para NUNCA gravar a senha em texto puro.
// ============================================================

$dados = json_decode(file_get_contents('php://input'), true) ?? []; // lê o corpo da requisição

$nome = trim($dados['nome'] ?? '');
$email = trim($dados['email'] ?? '');
$senha = $dados['senha'] ?? '';

if ($nome === '' || $email === '' || $senha === '') {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Preencha todos os campos.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Digite um e-mail válido.']);
    exit;
}


if (strlen($senha) < 6) {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'A senha deve ter pelo menos 6 caracteres.']);
    exit;
}

// Impede e-mails duplicados: consulta parametrizada (o "?" impede SQL Injection)
$verifica = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
$verifica->execute([$email]);

if ($verifica->fetch()) {
    http_response_code(409);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Este e-mail já está cadastrado.']);
    exit;
}

// Gera um hash irreversível da senha (bcrypt) antes de salvar
$hash = password_hash($senha, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
$stmt->execute([$nome, $email, $hash]);

echo json_encode(['sucesso' => true, 'mensagem' => 'Cadastro realizado com sucesso!']);
exit;
