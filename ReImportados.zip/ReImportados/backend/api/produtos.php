<?php
// ============================================================
// produtos.php — Catálogo de produtos (painel administrativo)
// GET    -> lista produtos com busca, filtro por categoria e status de estoque
// POST   -> cadastra um novo produto
// PUT    -> atualiza os dados do produto (nome, preço, estoque, etc.)
// DELETE -> remove um produto
// == Destaque ==
// As consultas são sempre parametrizadas (com "?"), evitando SQL Injection.
// ============================================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    $busca = $_GET['busca'] ?? '';
    $categoria = $_GET['categoria'] ?? '';
    $status = $_GET['status'] ?? '';

    $sql = "SELECT id, nome, preco, imagem, categoria, estoque, estoque_min, ativo, criado_em FROM produtos WHERE 1=1";
    $params = [];

    if ($busca !== '') {
        $sql .= " AND nome LIKE ?"; // busca por trecho do nome
        $params[] = "%{$busca}%";
    }
    if ($categoria !== '') {
        $sql .= " AND categoria = ?"; // filtra por categoria exata
        $params[] = $categoria;
    }
    // Filtros de estoque criados a partir do campo estoque_min (nível de reposição)
    if ($status === 'sem_estoque') {
        $sql .= " AND estoque <= 0"; // produtos zerados
    } elseif ($status === 'estoque_baixo') {
        $sql .= " AND estoque > 0 AND estoque <= estoque_min"; // abaixo do nível mínimo
    } elseif ($status === 'estavel') {
        $sql .= " AND estoque > estoque_min"; // acima do nível mínimo
    }
    if (isset($_GET['ativos'])) {
        $ativos = (int)$_GET['ativos'];
        $sql .= $ativos ? " AND ativo = 1" : " AND ativo = 0"; // filtra ativos/desativados
    }

    $sql .= " ORDER BY id ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $produtos = $stmt->fetchAll();

    // Lista única de categorias para preencher os filtros do painel
    $cats = $pdo->query("SELECT DISTINCT categoria FROM produtos WHERE categoria IS NOT NULL ORDER BY categoria")->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode(['sucesso' => true, 'produtos' => $produtos, 'categorias' => $cats]);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true) ?? [];

if ($metodo === 'POST') {
    $nome = trim($dados['nome'] ?? '');
    $preco = (float)($dados['preco'] ?? 0);
    $imagem = trim($dados['imagem'] ?? '');
    $categoria = trim($dados['categoria'] ?? '');
    $estoque = (int)($dados['estoque'] ?? 0);
    $estoqueMin = isset($dados['estoque_min']) ? (int)$dados['estoque_min'] : 5;
    $ativo = isset($dados['ativo']) ? ($dados['ativo'] ? 1 : 0) : 1;

    if ($nome === '' || $preco <= 0) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Nome e preço são obrigatórios.']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO produtos (nome, preco, imagem, categoria, estoque, estoque_min, ativo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$nome, $preco, $imagem, $categoria, $estoque, $estoqueMin, $ativo]);
    $novoId = $pdo->lastInsertId(); // recupera o ID gerado automaticamente

    echo json_encode(['sucesso' => true, 'produto_id' => (int)$novoId, 'mensagem' => 'Produto criado com sucesso!']);
    exit;
}

if ($metodo === 'PUT') {
    $id = (int)($dados['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID do produto inválido.']);
        exit;
    }

    $campos = [];
    $params = [];

    if (isset($dados['nome'])) { $campos[] = "nome = ?"; $params[] = trim($dados['nome']); }
    if (isset($dados['preco'])) { $campos[] = "preco = ?"; $params[] = (float)$dados['preco']; }
    if (isset($dados['imagem'])) { $campos[] = "imagem = ?"; $params[] = trim($dados['imagem']); }
    if (isset($dados['categoria'])) { $campos[] = "categoria = ?"; $params[] = trim($dados['categoria']); }
    if (isset($dados['estoque'])) { $campos[] = "estoque = ?"; $params[] = (int)$dados['estoque']; }
    if (isset($dados['estoque_min'])) { $campos[] = "estoque_min = ?"; $params[] = (int)$dados['estoque_min']; }
    if (array_key_exists('ativo', $dados)) { $campos[] = "ativo = ?"; $params[] = $dados['ativo'] ? 1 : 0; }

    if (empty($campos)) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Nenhum campo para atualizar.']);
        exit;
    }

    $params[] = $id;
    $stmt = $pdo->prepare("UPDATE produtos SET " . implode(', ', $campos) . " WHERE id = ?");
    $stmt->execute($params);

    echo json_encode(['sucesso' => true, 'mensagem' => 'Produto atualizado com sucesso!']);
    exit;
}

if ($metodo === 'DELETE') {
    $id = (int)($dados['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID do produto inválido.']);
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode(['sucesso' => true, 'mensagem' => 'Produto removido com sucesso!']);
    exit;
}

http_response_code(405);
echo json_encode(['sucesso' => false, 'mensagem' => 'Método não suportado.']);
exit;
