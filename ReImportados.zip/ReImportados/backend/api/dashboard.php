<?php
// ============================================================
// dashboard.php — Indicadores do painel administrativo
// Reúne estatísticas do banco para alimentar os cards e gráficos:
// vendas, receita (mês/semana), estoque, usuários, produtos mais
// vendidos e a série de pedidos por mês (últimos 12 meses).
// ============================================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

$stats = [];

$r = $pdo->query("SELECT COUNT(*) AS total FROM produtos");
$stats['total_produtos'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COALESCE(SUM(estoque),0) AS total FROM produtos");
$stats['total_estoque'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM produtos WHERE estoque <= 0");
$stats['sem_estoque'] = (int)$r->fetch()['total'];

// "Estoque baixo" considera o nível mínimo definido por produto (estoque_min)
$r = $pdo->query("SELECT COUNT(*) AS total FROM produtos WHERE estoque > 0 AND estoque <= estoque_min");
$stats['estoque_baixo'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COALESCE(SUM(p.preco * c.quantidade),0) AS valor FROM carrinho c JOIN produtos p ON p.id = c.produto_id");
$stats['valor_carrinho'] = (float)$r->fetch()['valor'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM usuarios");
$stats['total_usuarios'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM usuarios WHERE admin = 1");
$stats['total_admins'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM pedidos");
$stats['total_pedidos'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM pedidos WHERE status = 'confirmado'");
$stats['pedidos_pendentes'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM pedidos WHERE status = 'enviado'");
$stats['pedidos_enviados'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM pedidos WHERE status = 'entregue'");
$stats['pedidos_entregues'] = (int)$r->fetch()['total'];

$r = $pdo->query("SELECT COALESCE(SUM(total),0) AS valor FROM pedidos");
$stats['receita_total'] = (float)$r->fetch()['valor'];

// Receita do mês atual (compare o mês/ano do pedido com o atual)
$r = $pdo->query("SELECT COALESCE(SUM(total),0) AS valor FROM pedidos WHERE MONTH(criado_em) = MONTH(NOW()) AND YEAR(criado_em) = YEAR(NOW())");
$stats['receita_mes'] = (float)$r->fetch()['valor'];

// Receita dos últimos 7 dias
$r = $pdo->query("SELECT COALESCE(SUM(total),0) AS valor FROM pedidos WHERE criado_em >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stats['receita_semana'] = (float)$r->fetch()['valor'];

$r = $pdo->query("SELECT COUNT(*) AS total FROM pedidos WHERE criado_em >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stats['pedidos_semana'] = (int)$r->fetch()['total'];

// Top 5 produtos mais vendidos nos últimos 30 dias (ordena pela soma das quantidades)
$r = $pdo->query(
    "SELECT p.nome, p.estoque, p.preco, pi.quantidade
     FROM pedido_itens pi
     JOIN produtos p ON p.id = pi.produto_id
     JOIN pedidos pd ON pd.id = pi.pedido_id
     WHERE pd.criado_em >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY p.id
     ORDER BY SUM(pi.quantidade) DESC
     LIMIT 5"
);
$stats['produtos_mais_vendidos'] = $r->fetchAll();

// Pedidos recentes (para o feed de atividades do dashboard)
$recentOrders = $pdo->query(
    "SELECT pd.id, pd.total, pd.status, pd.forma_pagamento, pd.criado_em, u.nome AS cliente_nome
     FROM pedidos pd
     JOIN usuarios u ON u.id = pd.usuario_id
     ORDER BY pd.criado_em DESC
     LIMIT 8"
)->fetchAll();

// Usuários recém-cadastrados (feed de atividades)
$recentUsers = $pdo->query(
    "SELECT id, nome, email, admin, criado_em
     FROM usuarios
     ORDER BY criado_em DESC
     LIMIT 5"
)->fetchAll();

// Estoque somado por categoria (alimenta o gráfico de rosca)
$stockByCategory = $pdo->query(
    "SELECT COALESCE(categoria, 'Sem categoria') AS categoria, COUNT(*) AS qtd, COALESCE(SUM(estoque),0) AS estoque_total
     FROM produtos
     GROUP BY categoria
     ORDER BY estoque_total DESC"
)->fetchAll();

// Série mensal de pedidos e receita (gráfico de barras/linha dos últimos 12 meses)
$monthlyOrders = $pdo->query(
    "SELECT DATE_FORMAT(criado_em, '%Y-%m') AS mes, COUNT(*) AS qtd, COALESCE(SUM(total),0) AS valor
     FROM pedidos
     WHERE criado_em >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
     GROUP BY mes
     ORDER BY mes ASC"
)->fetchAll();

echo json_encode([
    'sucesso' => true,
    'stats' => $stats,
    'pedidos_recentes' => $recentOrders,
    'usuarios_recentes' => $recentUsers,
    'estoque_por_categoria' => $stockByCategory,
    'pedidos_por_mes' => $monthlyOrders,
]);
exit;
