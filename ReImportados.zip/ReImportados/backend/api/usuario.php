<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

// ============================================================
// usuario.php — Retorna os dados do usuário logado
// Protegida por sessão: se não houver usuário_id na sessão,
// a API responde 401 (não autorizado).
// ============================================================

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'É necessário fazer login.']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

// Consulta parametrizada trazendo apenas dados públicos (sem a senha)
$stmt = $pdo->prepare("SELECT id, nome, email FROM usuarios WHERE id = ?");
$stmt->execute([$usuarioId]);
$usuario = $stmt->fetch();

if (!$usuario) {
    http_response_code(404);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado.']);
    exit;
}

echo json_encode([
    'sucesso' => true,
    'usuario' => [
        'id'    => (int)$usuario['id'],
        'nome'  => $usuario['nome'],
        'email' => $usuario['email'],
    ],
]);
exit;
