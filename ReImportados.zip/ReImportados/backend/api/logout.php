<?php
// ============================================================
// logout.php — Encerra a sessão do usuário
// Limpa todas as variáveis da sessão e destrói o arquivo de
// sessão no servidor, "deslogando" o usuário com segurança.
// ============================================================
session_start();
header('Content-Type: application/json; charset=utf-8');

$_SESSION = [];      // esvazia os dados guardados
session_destroy();   // encerra a sessão de vez

echo json_encode(['sucesso' => true]);
exit;
