<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/enviar_codigo.php';

// ============================================================
// verificar_email.php — Reenvia o código de verificação por e-mail
// Usado na tela de verificação quando o cliente pede um novo código
// (o e-mail costuma cair no Spam do Gmail).
// ============================================================

$email = $_SESSION['email_pendente'] ?? trim($_POST['email'] ?? '');
if ($email === '') {
    $dados = json_decode(file_get_contents('php://input'), true) ?? [];
    $email = trim($dados['email'] ?? '');
}
if ($email === '' && isset($_GET['email'])) {
    $email = trim($_GET['email']);
}

if ($email === '') {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'E-mail pendente não encontrado. Faça login novamente.']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, nome FROM usuarios WHERE email = ?");
$stmt->execute([$email]);
$usuario = $stmt->fetch();

if (!$usuario) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado.']);
    exit;
}

// Gera novo código e salva (o anterior fica para expirar/trocar)
$codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$expiraEm = date('Y-m-d H:i:s', time() + 900);

$stmt = $pdo->prepare("INSERT INTO codigos_verificacao (usuario_id, codigo, expira_em) VALUES (?, ?, ?)");
$stmt->execute([$usuario['id'], $codigo, $expiraEm]);

// Envia o e-mail (mesma lógica do login)
$enviado = enviarCodigoEmail($email, $codigo, $usuario['nome']);

echo json_encode([
    'sucesso' => true,
    'email' => $email,
    'mensagem' => 'Novo código enviado para ' . $email . ' (verifique o spam).',
    'email_enviado' => $enviado,
    'dev_codigo' => $enviado ? null : $codigo,
]);
exit;