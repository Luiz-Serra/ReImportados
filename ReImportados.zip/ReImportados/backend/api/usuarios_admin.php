<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

// ============================================================
// usuarios_admin.php — Gestão de usuários (painel administrativo)
// GET  -> lista usuários com busca e filtro (admin/cliente)
// PUT  -> promove ou rebaixa um usuário (admin = 1/0)
// DELETE -> exclui um usuário
// == Observação ==
// (O controle de acesso administrativo foi flexibilizado durante
//  o desenvolvimento, conforme SESSAO.md — verificar antes de produção.)
// ============================================================

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    $busca = $_GET['busca'] ?? '';
    $role = $_GET['role'] ?? '';

    // Subqueries contam pedidos, valor gasto e itens no carrinho de cada usuário
    $sql = "SELECT u.id, u.nome, u.email, u.admin, u.criado_em,
                   (SELECT COUNT(*) FROM pedidos WHERE usuario_id = u.id) AS qtd_pedidos,
                   (SELECT COALESCE(SUM(total),0) FROM pedidos WHERE usuario_id = u.id) AS valor_gasto,
                   (SELECT COUNT(*) FROM carrinho WHERE usuario_id = u.id) AS itens_carrinho
            FROM usuarios u WHERE 1=1";
    $params = [];

    if ($busca !== '') {
        $sql .= " AND (u.nome LIKE ? OR u.email LIKE ?)"; // busca por nome ou e-mail
        $params[] = "%{$busca}%";
        $params[] = "%{$busca}%";
    }
    if ($role === 'admin') {
        $sql .= " AND u.admin = 1"; // filtra administradores
    } elseif ($role === 'cliente') {
        $sql .= " AND u.admin = 0"; // filtra clientes comuns
    }

    $sql .= " ORDER BY u.criado_em DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $usuarios = $stmt->fetchAll();

    // Resumo geral (totais) usado nos cartões da tela de usuários
    $r = $pdo->query("SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN admin=1 THEN 1 ELSE 0 END) AS admins,
        SUM(CASE WHEN admin=0 THEN 1 ELSE 0 END) AS clientes
        FROM usuarios")->fetch();

    echo json_encode(['sucesso' => true, 'usuarios' => $usuarios, 'resumo' => $r]);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true) ?? [];

if ($metodo === 'PUT') {
    $id = (int)($dados['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID inválido.']);
        exit;
    }

    if (isset($dados['admin'])) { // permite tornar o usuário admin (1) ou cliente (0)
        $isAdmin = $dados['admin'] ? 1 : 0;
        $stmt = $pdo->prepare("UPDATE usuarios SET admin = ? WHERE id = ?");
        $stmt->execute([$isAdmin, $id]);
    }

    echo json_encode(['sucesso' => true, 'mensagem' => 'Usuário atualizado com sucesso!']);
    exit;
}

if ($metodo === 'DELETE') {
    $id = (int)($dados['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID inválido.']);
        exit;
    }
    // Não deixa o usuário excluir a própria conta (evita "derrubar" o admin logado)
    if ($id === $_SESSION['usuario_id']) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Você não pode excluir sua própria conta.']);
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?"); // cascata apaga carrinho/endereços
    $stmt->execute([$id]);

    echo json_encode(['sucesso' => true, 'mensagem' => 'Usuário removido com sucesso!']);
    exit;
}

http_response_code(405);
echo json_encode(['sucesso' => false, 'mensagem' => 'Método não suportado.']);
exit;
