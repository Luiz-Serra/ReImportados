<?php
// ============================================================
// pedido.php — Finalização da compra (o coração do checkout)
// Converte o carrinho em um pedido real no banco.
// == Pontos-chave ==
//  * Usa TRANSAÇÃO: ou tudo grava, ou nada grava (atomicidade).
//  * FOR UPDATE trava as linhas para não vender além do estoque.
//  * Baixa o estoque dos produtos vendidos.
//  * Grava o endereço de entrega escolhido no pedido.
// ============================================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'É necessário fazer login para finalizar a compra.']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];
$dados = json_decode(file_get_contents('php://input'), true) ?? [];
$formaPagamento = $dados['forma_pagamento'] ?? 'não informado';
$pagamentoTipo = trim($dados['pagamento_tipo'] ?? '');
$parcelas = isset($dados['parcelas']) ? (int)$dados['parcelas'] : null;
$enderecoId = isset($dados['endereco_id']) ? (int)$dados['endereco_id'] : null;

$TAXA_ENVIO = 15.00;

// Se informado, garante que o endereço pertence ao usuário logado
if ($enderecoId) {
    $stmtEnd = $pdo->prepare("SELECT id FROM enderecos WHERE id = ? AND usuario_id = ?");
    $stmtEnd->execute([$enderecoId, $usuarioId]);
    if (!$stmtEnd->fetch()) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Endereço de entrega inválido.']);
        exit;
    }
}

try {
    $pdo->beginTransaction();

    // Consulta os itens do carrinho junto com o estoque disponível, bloqueando
    // as linhas (FOR UPDATE) para evitar venda além do estoque em acessos concorrentes.
    $stmt = $pdo->prepare(
        "SELECT c.produto_id, c.quantidade, p.nome, p.preco, p.estoque, p.ativo
         FROM carrinho c
         JOIN produtos p ON p.id = c.produto_id
         WHERE c.usuario_id = ?
         ORDER BY c.id
         FOR UPDATE"
    );
    $stmt->execute([$usuarioId]);
    $itens = $stmt->fetchAll();

    if (!$itens) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Seu carrinho está vazio.']);
        exit;
    }

    // Valida estoque de todos os itens antes de processar
    foreach ($itens as $item) {
        if (!$item['ativo']) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => "O produto \"{$item['nome']}\" está indisponível."]);
            exit;
        }
        if ($item['quantidade'] > $item['estoque']) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode([
                'sucesso' => false,
                'mensagem' => "Estoque insuficiente para um dos itens. Disponível: {$item['estoque']}.",
            ]);
            exit;
        }
    }

    $subtotal = 0;
    $totalItens = 0;
    foreach ($itens as $item) {
        $subtotal += $item['preco'] * $item['quantidade'];
        $totalItens += $item['quantidade'];
    }
    $total = $subtotal + $TAXA_ENVIO;

    // Monta o detalhamento do pagamento (ex.: "credit 3x", "credit à vista", "pix", "boleto", "debit")
    if ($pagamentoTipo === '' && $formaPagamento !== 'não informado') {
        $pagamentoTipo = $formaPagamento;
    }
    if ($formaPagamento === 'credit') {
        $pagamentoTipo = 'credit ' . ($parcelas && $parcelas > 1 ? $parcelas . 'x' : 'à vista');
    } elseif ($parcelas === null) {
        $parcelas = ($formaPagamento === 'credit') ? 1 : null;
    }

    $stmtPedido = $pdo->prepare(
        "INSERT INTO pedidos (usuario_id, endereco_id, subtotal, frete, total,
                              forma_pagamento, pagamento_tipo, parcelas, itens_carrinho, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmado')"
    );
    $stmtPedido->execute([
        $usuarioId, $enderecoId, $subtotal, $TAXA_ENVIO, $total,
        $formaPagamento, $pagamentoTipo, $parcelas, $totalItens,
    ]);
    $pedidoId = $pdo->lastInsertId();

    $stmtItem = $pdo->prepare(
        "INSERT INTO pedido_itens (pedido_id, produto_id, quantidade, preco_unitario) VALUES (?, ?, ?, ?)"
    );
    // Baixa o estoque de cada produto e insere o item
    $stmtBaixa = $pdo->prepare("UPDATE produtos SET estoque = estoque - ? WHERE id = ? AND ativo = 1");
    foreach ($itens as $item) {
        $stmtItem->execute([$pedidoId, $item['produto_id'], $item['quantidade'], $item['preco']]);
        $stmtBaixa->execute([$item['quantidade'], $item['produto_id']]); // subtrai da quantidade vendida
    }

    // Limpa o carrinho do usuário após a compra concluída
    $stmtLimpa = $pdo->prepare("DELETE FROM carrinho WHERE usuario_id = ?");
    $stmtLimpa->execute([$usuarioId]);

    $pdo->commit(); // confirma TUDO de uma só vez (só agora os dados são salvos)

    echo json_encode([
        'sucesso' => true,
        'pedido_id' => $pedidoId,
        'subtotal' => $subtotal,
        'frete' => $TAXA_ENVIO,
        'total' => $total,
    ]);
} catch (Exception $erro) {
    // Se algo falhar no meio, desfaz TODA a transação (nada fica pela metade)
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao processar o pedido. Tente novamente.']);
    exit;
}
