<?php
// ============================================================
// pedidos_admin.php — Gestão de pedidos (painel administrativo)
// GET -> lista pedidos (filtros por status/busca) + totalizadores
// PUT -> altera o status (confirmado/enviado/entregue/cancelado)
// == Regra importante ==
// Ao CANCELAR um pedido, o estoque baixado na venda é devolvido
// ao produto (apenas uma vez, evitando dupla reposição).
// ============================================================
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    $status = $_GET['status'] ?? '';
    $busca = $_GET['busca'] ?? '';

    // LEFT JOIN traz o endereço de entrega junto, mesmo quando não há endereço
    $sql = "SELECT pd.id, pd.total, pd.subtotal, pd.frete, pd.status,
                   pd.forma_pagamento, pd.pagamento_tipo, pd.parcelas,
                   pd.endereco_id, pd.criado_em, pd.atualizado_em,
                   u.id AS usuario_id, u.nome AS cliente_nome, u.email AS cliente_email,
                   e.cep AS entrega_cep, e.rua AS entrega_rua,
                   e.numero AS entrega_numero, e.complemento AS entrega_complemento,
                   e.cidade AS entrega_cidade, e.uf AS entrega_uf, e.bairro AS entrega_bairro,
                   (SELECT COUNT(*) FROM pedido_itens WHERE pedido_id = pd.id) AS qtd_itens
            FROM pedidos pd
            JOIN usuarios u ON u.id = pd.usuario_id
            LEFT JOIN enderecos e ON e.id = pd.endereco_id
            WHERE 1=1";
    $params = [];

    if ($status !== '') {
        $sql .= " AND pd.status = ?";
        $params[] = $status;
    }
    if ($busca !== '') {
        $sql .= " AND (u.nome LIKE ? OR u.email LIKE ? OR pd.id = ?)";
        $params[] = "%{$busca}%";
        $params[] = "%{$busca}%";
        $params[] = (int)$busca;
    }

    $sql .= " ORDER BY pd.criado_em DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $pedidos = $stmt->fetchAll();

    // Totalizadores gerais usados nos cartões do painel de pedidos
    $resumo = [
        'total' => 0,
        'pendentes' => 0,
        'enviados' => 0,
        'entregues' => 0,
        'cancelados' => 0,
        'valor_total' => 0,
    ];

    $r = $pdo->query("SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status='confirmado' THEN 1 ELSE 0 END) AS pendentes,
        SUM(CASE WHEN status='enviado' THEN 1 ELSE 0 END) AS enviados,
        SUM(CASE WHEN status='entregue' THEN 1 ELSE 0 END) AS entregues,
        SUM(CASE WHEN status='cancelado' THEN 1 ELSE 0 END) AS cancelados,
        COALESCE(SUM(total),0) AS valor_total
        FROM pedidos")->fetch();
    if ($r) $resumo = array_merge($resumo, $r);

    echo json_encode(['sucesso' => true, 'pedidos' => $pedidos, 'resumo' => $resumo]);
    exit;
}

if ($metodo === 'PUT') {
    $dados = json_decode(file_get_contents('php://input'), true);
    $id = (int)($dados['id'] ?? 0);
    $novoStatus = trim($dados['status'] ?? '');

    if ($id <= 0 || $novoStatus === '') {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID e status são obrigatórios.']);
        exit;
    }

    $statusPermitidos = ['confirmado', 'enviado', 'entregue', 'cancelado'];
    if (!in_array($novoStatus, $statusPermitidos)) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Status inválido.']);
        exit;
    }

    // Busca o status atual para controlar reposição de estoque
    $stmtAtual = $pdo->prepare("SELECT status FROM pedidos WHERE id = ?");
    $stmtAtual->execute([$id]);
    $atual = $stmtAtual->fetch();
    $statusAnterior = $atual ? $atual['status'] : null;

    $stmt = $pdo->prepare("UPDATE pedidos SET status = ? WHERE id = ?");
    $stmt->execute([$novoStatus, $id]);

    // Ao cancelar, devolve o estoque que foi baixado na venda (apenas uma vez)
    if ($novoStatus === 'cancelado' && $statusAnterior !== 'cancelado') {
        $itensStmt = $pdo->prepare(
            "SELECT pi.produto_id, pi.quantidade FROM pedido_itens pi WHERE pi.pedido_id = ?"
        );
        $itensStmt->execute([$id]);
        $itens = $itensStmt->fetchAll();
        foreach ($itens as $item) {
            $pdo->prepare("UPDATE produtos SET estoque = estoque + ? WHERE id = ?")->execute([$item['quantidade'], $item['produto_id']]);
        }
    }

    echo json_encode(['sucesso' => true, 'mensagem' => 'Status atualizado com sucesso!']);
    exit;
}

http_response_code(405);
echo json_encode(['sucesso' => false, 'mensagem' => 'Método não suportado.']);
exit;
