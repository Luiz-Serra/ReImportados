<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

// ============================================================
// endereco.php — Cadastro e gestão de endereços de entrega
// Um usuário pode ter vários endereços; o campo "padrao"
// marca o endereço principal usado no checkout.
// GET    -> lista endereços do usuário
// POST   -> cadastra novo endereço
// PUT    -> define qual endereço é o padrão
// DELETE -> remove um endereço
// ============================================================

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'É necessário fazer login.']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];
$method = $_SERVER['REQUEST_METHOD'];

// GET: listar endereços do usuário (padrão aparece primeiro)
if ($method === 'GET') {
    $stmt = $pdo->prepare("SELECT * FROM enderecos WHERE usuario_id = ? ORDER BY padrao DESC, criado_em DESC");
    $stmt->execute([$usuarioId]);
    $enderecos = $stmt->fetchAll();
    echo json_encode(['sucesso' => true, 'enderecos' => $enderecos]);
    exit;
}

// POST: cadastrar novo endereço
if ($method === 'POST') {
    $dados = json_decode(file_get_contents('php://input'), true) ?? [];
    $cpf     = preg_replace('/\D/', '', $dados['cpf'] ?? '');
    $cep     = preg_replace('/\D/', '', $dados['cep'] ?? '');
    $rua     = trim($dados['rua'] ?? '');
    $numero  = trim($dados['numero'] ?? '');
    $complemento = trim($dados['complemento'] ?? '');
    $cidade  = trim($dados['cidade'] ?? '');
    $uf      = strtoupper(trim($dados['uf'] ?? ''));
    $bairro  = trim($dados['bairro'] ?? '');
    $padrao  = !empty($dados['padrao']) ? 1 : 0;

    if (!$cpf || !$cep || !$rua || !$numero || !$cidade || strlen($uf) !== 2) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Preencha CPF, cep, rua, número, cidade e UF.']);
        exit;
    }

    if (strlen($cpf) !== 11) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'CPF inválido. Digite 11 dígitos.']);
        exit;
    }

    // Só pode haver UM endereço padrão: se o novo será padrão, tira o padrão dos demais
    if ($padrao) {
        $stmt = $pdo->prepare("UPDATE enderecos SET padrao = 0 WHERE usuario_id = ?");
        $stmt->execute([$usuarioId]);
    }

    // Se é o primeiro endereço, marca como padrão automaticamente
    $stmtCount = $pdo->prepare("SELECT COUNT(*) AS total FROM enderecos WHERE usuario_id = ?");
    $stmtCount->execute([$usuarioId]);
    $total = $stmtCount->fetch()['total'];
    if ($total == 0) {
        $padrao = 1;
    }

    $stmt = $pdo->prepare(
        "INSERT INTO enderecos (usuario_id, cpf, cep, rua, numero, complemento, cidade, uf, bairro, padrao)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$usuarioId, $cpf, $cep, $rua, $numero, $complemento, $cidade, $uf, $bairro, $padrao]);
    $novoId = $pdo->lastInsertId();

    echo json_encode(['sucesso' => true, 'endereco_id' => (int)$novoId]);
    exit;
}

// PUT: definir endereço padrão
if ($method === 'PUT') {
    $dados = json_decode(file_get_contents('php://input'), true) ?? [];
    $enderecoId = (int)($dados['endereco_id'] ?? 0);

    if (!$enderecoId) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID do endereço é obrigatório.']);
        exit;
    }

    // Desmarca todos...  (passo 1: nenhum padrão)
    $stmt = $pdo->prepare("UPDATE enderecos SET padrao = 0 WHERE usuario_id = ?");
    $stmt->execute([$usuarioId]);

    // ...e marca apenas o escolhido (passo 2: padrão = 1)
    $stmt = $pdo->prepare("UPDATE enderecos SET padrao = 1 WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$enderecoId, $usuarioId]);

    echo json_encode(['sucesso' => true]);
    exit;
}

// DELETE: remover endereço
if ($method === 'DELETE') {
    $dados = json_decode(file_get_contents('php://input'), true) ?? [];
    $enderecoId = (int)($dados['endereco_id'] ?? 0);

    if (!$enderecoId) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'ID do endereço é obrigatório.']);
        exit;
    }

    // WHERE com AND usuario_id garante que só o dono apaga o próprio endereço
    $stmt = $pdo->prepare("DELETE FROM enderecos WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$enderecoId, $usuarioId]);

    echo json_encode(['sucesso' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido.']);
exit;
