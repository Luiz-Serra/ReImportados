<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/conexao.php';

// ============================================================
// confirmar_email.php — Confirma o código de verificação de email
// O código foi enviado ao entrar no login (login.php). Aqui o
// cliente digita o código e, se estiver correto, a sessão é criada.
// ============================================================

$dados = json_decode(file_get_contents('php://input'), true) ?? [];

$email = $_SESSION['email_pendente'] ?? trim($dados['email'] ?? '');
$codigo = trim(preg_replace('/\D/', '', $dados['codigo'] ?? ''));

if ($email === '' || $codigo === '') {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Informe o código recebido por e-mail.']);
    exit;
}

// Localiza o usuário pelo e-mail pendente
$stmt = $pdo->prepare("SELECT id, nome, admin FROM usuarios WHERE email = ?");
$stmt->execute([$email]);
$usuario = $stmt->fetch();

if (!$usuario) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado.']);
    exit;
}

// Busca o código mais recente não utilizado
$stmt = $pdo->prepare(
    "SELECT * FROM codigos_verificacao
     WHERE usuario_id = ? AND utilizado = 0
     ORDER BY id DESC LIMIT 1"
);
$stmt->execute([$usuario['id']]);
$registro = $stmt->fetch();

if (!$registro || $registro['codigo'] !== $codigo) {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Código inválido.']);
    exit;
}

if (strtotime($registro['expira_em']) < time()) {
    http_response_code(400);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Código expirado. Solicite um novo.']);
    exit;
}

// Marca o código como usado e cria a sessão do cliente.
// Obs.: mantém o MESMO ID de sessão do login (não chamar
// session_regenerate_id aqui, para o navegador não perder o cookie
// de sessão entre a tela de verificação e a loja).
$stmt = $pdo->prepare("UPDATE codigos_verificacao SET utilizado = 1 WHERE id = ?");
$stmt->execute([$registro['id']]);

$_SESSION['usuario_id'] = $usuario['id'];
$_SESSION['nome'] = $usuario['nome'];
$_SESSION['admin'] = (bool) $usuario['admin'];
unset($_SESSION['email_pendente']);

echo json_encode([
    'sucesso' => true,
    'nome' => $usuario['nome'],
    'admin' => (bool) $usuario['admin'],
    'mensagem' => 'E-mail verificado! Bem-vindo de volta.',
]);
exit;