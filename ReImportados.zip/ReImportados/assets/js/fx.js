/* ============================================================
   fx.js — apenas efeitos visuais (não contém lógica de negócio).
   Seguro para carregar em qualquer página: observa elementos,
   revela com scroll e adiciona pequenos toques de interatividade.
   ============================================================ */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function markRevealTargets() {
    var selectors = [
      ".product-card", ".help-card", ".auth-card", ".stat-card",
      ".chart-card", ".activity-item", ".order-item", ".resumo-compra",
      ".carrinho-container .lista-produtos > *", ".hero-container",
      ".filter-card"
    ];
    var seen = new Set();
    selectors.forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) {
        if (!seen.has(el)) {
          el.classList.add("fx-reveal");
          seen.add(el);
        }
      });
    });
  }

  // Revela cada elemento conforme entra na tela usando IntersectionObserver
  // (API nativa do navegador que detecta quando um elemento fica visível)
  function observeReveal() {
    var items = document.querySelectorAll(".fx-reveal");
    // Se o usuário pedir menos movimento, mostra tudo de uma vez (acessibilidade)
    if (reduceMotion || !("IntersectionObserver" in window)) {
      items.forEach(function (el) { el.classList.add("fx-in"); });
      return;
    }
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry, i) {
          if (entry.isIntersecting) {
            setTimeout(function () {
              entry.target.classList.add("fx-in");
            }, Math.min(i * 60, 360));
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    items.forEach(function (el) { io.observe(el); });
  }

  // reobserva quando novo conteúdo é injetado dinamicamente (ex: template de categoria)
  function watchDynamicContent() {
    var main = document.querySelector(".products-section, main, body");
    if (!main || !("MutationObserver" in window)) return;
    var mo = new MutationObserver(function () {
      markRevealTargets();
      observeReveal();
    });
    mo.observe(main, { childList: true, subtree: true });
  }

  // header muda de aparência ao rolar
  function headerOnScroll() {
    var header = document.querySelector("header");
    if (!header) return;
    var onScroll = function () {
      header.classList.toggle("fx-scrolled", window.scrollY > 12);
    };
    document.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  // brilho que segue o cursor nos cards (desktop apenas)
  function cardGlowFollow() {
    if (reduceMotion || matchMedia("(pointer: coarse)").matches) return;
    document.addEventListener("pointermove", function (e) {
      var card = e.target.closest(".fx-glass, .help-card, .auth-card");
      if (!card) return;
      var rect = card.getBoundingClientRect();
      card.style.setProperty("--mx", ((e.clientX - rect.left) / rect.width * 100) + "%");
      card.style.setProperty("--my", ((e.clientY - rect.top) / rect.height * 100) + "%");
    });
  }

  function init() {
    markRevealTargets();
    observeReveal();
    watchDynamicContent();
    headerOnScroll();
    cardGlowFollow();
    backToTop();
    staggerCards();
    parallaxHero();
    rippleButtons();
  }

  function backToTop() {
    var btn = document.getElementById('back-to-top');
    if (!btn) return;
    window.addEventListener('scroll', function () {
      btn.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });
    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // entrada escalonada dos cards
  function staggerCards() {
    if (reduceMotion) return;
    var cards = document.querySelectorAll('.product-card');
    if (!cards.length) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var idx = Array.prototype.indexOf.call(cards, entry.target);
          entry.target.style.transitionDelay = (idx * 80) + 'ms';
          entry.target.classList.add('fx-in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    cards.forEach(function (c) { c.classList.add('fx-reveal'); io.observe(c); });
  }

  // parallax sutil no hero ao rolar
  function parallaxHero() {
    if (reduceMotion) return;
    var hero = document.querySelector('.hero-image-wrapper');
    if (!hero) return;
    window.addEventListener('scroll', function () {
      var y = window.scrollY;
      if (y < 800) {
        hero.style.transform = 'translateY(' + (y * 0.08) + 'px)';
      }
    }, { passive: true });
  }

  // efeito ripple dourado nos botões
  function rippleButtons() {
    if (reduceMotion) return;
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('.add-to-cart-btn, .auth-btn, .btn-finalizar, .checkout-btn, .btn-finalize-order, .send-btn');
      if (!btn) return;
      var rect = btn.getBoundingClientRect();
      var ripple = document.createElement('span');
      ripple.className = 'fx-ripple';
      var size = Math.max(rect.width, rect.height);
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
      ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
      btn.appendChild(ripple);
      setTimeout(function () { ripple.remove(); }, 600);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
