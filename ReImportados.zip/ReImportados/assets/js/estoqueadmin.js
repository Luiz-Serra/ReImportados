// ============================================================
// estoqueadmin.js — Painel administrativo da loja
// Consome as APIs de admin e renderiza:
//   * Dashboard com cards de indicadores e gráficos (Chart.js)
//   * CRUD de produtos / estoque
//   * Gestão de pedidos (troca de status)
//   * Gestão de usuários (promover/excluir)
// ============================================================
const API_BASE = '../backend/api/';
let lineChartInstance = null; // guarda o gráfico de linhas atual (para destruir no reload)
let pieChartInstance = null;  // guarda o gráfico de rosca atual
let confirmCallback = null;   // função executada ao confirmar um modal

/* ==========================================
   UTILITÁRIOS
   ========================================== */
function formatarPreco(v) {
    return 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',');
}

function formatarData(str) {
    if (!str) return '-';
    const d = new Date(str);
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
}

function formatarDataHora(str) {
    if (!str) return '-';
    const d = new Date(str);
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) +
           ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function showToast(msg, tipo) {
    const toast = document.getElementById('admin-toast');
    toast.textContent = msg;
    toast.className = 'admin-toast show ' + (tipo || 'success');
    setTimeout(() => { toast.className = 'admin-toast'; }, 3500);
}

function statusBadge(status) {
    const map = {
        'confirmado': ['Pendente', 'pending'],
        'enviado': ['Enviado', 'shipped'],
        'entregue': ['Entregue', 'delivered'],
        'cancelado': ['Cancelado', 'cancelled'],
    };
    const [label, cls] = map[status] || [status, ''];
    return `<span class="status-badge ${cls}">${label}</span>`;
}

// Retorna um "selo" visual conforme o nível de estoque do produto
// (usado na coluna de estoque da tabela de produtos)
function estoqueBadge(qtd) {
    qtd = parseInt(qtd);
    if (qtd <= 0) return '<span class="status-badge cancelled">Sem Estoque</span>';
    if (qtd < 10) return '<span class="status-badge pending">Crítico</span>';
    return '<span class="status-badge delivered">Estável</span>';
}

function showConfirm(title, message, callback) {
    document.getElementById('confirm-title').textContent = title;
    document.getElementById('confirm-message').textContent = message;
    confirmCallback = callback;
    document.getElementById('modal-confirm').classList.add('active');
}

function closeAllModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
}

/* ==========================================
   PROTEÇÃO DE ACESSO
   ========================================== */
async function protegerPagina() {
    try {
        const resp = await fetch(API_BASE + 'sessao.php');
        const dados = await resp.json();
        document.getElementById('admin-nome').textContent = dados.nome || 'Admin';
    } catch (erro) {
        document.getElementById('admin-nome').textContent = 'Admin';
    }
}

/* ==========================================
   NAVEGAÇÃO DA SIDEBAR
   ========================================== */
function initSidebar() {
    document.querySelectorAll('.nav-link[data-secao]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const secao = link.dataset.secao;
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
            const el = document.getElementById('section-' + secao);
            if (el) el.classList.add('active');
            if (secao === 'dashboard') carregarDashboard();
            if (secao === 'produtos') carregarProdutos();
            if (secao === 'pedidos') carregarPedidos();
            if (secao === 'usuarios') carregarUsuarios();
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.remove('open');
        });
    });

    document.querySelectorAll('.card-link[data-goto]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const target = document.querySelector(`.nav-link[data-secao="${link.dataset.goto}"]`);
            if (target) target.click();
        });
    });

    const toggle = document.getElementById('sidebar-toggle');
    toggle.addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('open');
    });

    document.getElementById('btn-logout').addEventListener('click', async (e) => {
        e.preventDefault();
        try { await fetch(API_BASE + 'logout.php', { method: 'POST' }); } catch (e) {}
        window.location.href = 'login.html';
    });
}

/* ==========================================
   DASHBOARD
   ========================================== */
// Carrega o dashboard: busca os indicadores e desenha os gráficos
async function carregarDashboard() {
    try {
        const resp = await fetch(API_BASE + 'dashboard.php');
        const dados = await resp.json();
        if (!dados.sucesso) return;
        // Cada chamada preenche uma parte da tela
        renderizarStats(dados.stats);
        renderizarGraficos(dados);
        renderizarPedidosRecentes(dados.pedidos_recentes);
        renderizarUsuariosRecentes(dados.usuarios_recentes);
        renderizarTopProdutos(dados.stats.produtos_mais_vendidos);
    } catch (erro) {
        console.error('Erro ao carregar dashboard:', erro);
    }
}

function renderizarStats(s) {
    document.getElementById('stat-receita-mes').textContent = formatarPreco(s.receita_mes);
    document.getElementById('stat-receita-semana-semana').textContent = formatarPreco(s.receita_semana) + ' (últimos 7 dias)';
    document.getElementById('stat-pedidos-semana').textContent = s.pedidos_semana;
    document.getElementById('stat-pedidos-total').textContent = s.total_pedidos + ' pedidos no total';
    document.getElementById('stat-total-produtos').textContent = s.total_produtos;
    document.getElementById('stat-total-estoque').textContent = s.total_estoque + ' em estoque';
    document.getElementById('stat-total-usuarios').textContent = s.total_usuarios;
    document.getElementById('stat-total-admins').textContent = s.total_admins + ' administradores';
    document.getElementById('stat-estoque-baixo').textContent = s.estoque_baixo;
    document.getElementById('stat-sem-estoque').textContent = s.sem_estoque + ' sem estoque';
    document.getElementById('stat-pedidos-pendentes').textContent = s.pedidos_pendentes;
    document.getElementById('stat-pedidos-enviados').textContent = s.pedidos_enviados + ' enviados';
}

// Prepara e desenha os dois gráficos com a biblioteca Chart.js:
// barras (receita) + linha (pedidos por mês) e rosca (estoque por categoria)
function renderizarGraficos(dados) {
    const meses = dados.pedidos_por_mes || [];
    const labels = meses.map(m => {
        const [y, mo] = m.mes.split('-');
        const nomes = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
        return nomes[parseInt(mo) - 1] + '/' + y.slice(2);
    });

    if (lineChartInstance) lineChartInstance.destroy();
    const ctxLine = document.getElementById('chartPedidosMes').getContext('2d');
    lineChartInstance = new Chart(ctxLine, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Receita (R$)',
                    data: meses.map(m => m.valor),
                    backgroundColor: 'rgba(201,162,39,0.7)',
                    borderColor: '#c9a227',
                    borderWidth: 1,
                    borderRadius: 6,
                    yAxisID: 'y',
                },
                {
                    label: 'Pedidos',
                    data: meses.map(m => m.qtd),
                    type: 'line',
                    borderColor: '#8b5cf6',
                    backgroundColor: 'rgba(139,92,246,0.1)',
                    borderWidth: 2,
                    pointBackgroundColor: '#8b5cf6',
                    tension: 0.4,
                    fill: true,
                    yAxisID: 'y1',
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#a9b3d6', font: { size: 10 }, callback: v => 'R$' + v },
                    grid: { color: 'rgba(140,160,255,0.08)' },
                    position: 'left'
                },
                y1: {
                    beginAtZero: true,
                    ticks: { color: '#8b5cf6', font: { size: 10 }, stepSize: 1 },
                    grid: { display: false },
                    position: 'right'
                },
                x: {
                    ticks: { color: '#a9b3d6', font: { size: 10 } },
                    grid: { display: false }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1a1d2b',
                    titleColor: '#c9a227',
                    bodyColor: '#fff',
                    cornerRadius: 8,
                    padding: 12
                }
            }
        }
    });

    const cats = dados.estoque_por_categoria || [];
    if (pieChartInstance) pieChartInstance.destroy();
    const ctxPie = document.getElementById('chartCategorias').getContext('2d');
    pieChartInstance = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: cats.map(c => c.categoria + ' (' + c.qtd + ')'),
            datasets: [{
                data: cats.map(c => c.estoque_total),
                backgroundColor: ['#c9a227', '#22e8e0', '#8b5cf6', '#ff3ea5', '#1a8a5c', '#d4960a', '#d43d51'],
                hoverOffset: 6,
                borderWidth: 0,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '65%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { boxWidth: 10, usePointStyle: true, padding: 12, color: '#a9b3d6', font: { size: 10 } }
                }
            }
        }
    });
}

function renderizarTopProdutos(produtos) {
    const container = document.getElementById('top-products-list');
    if (!produtos || produtos.length === 0) {
        container.innerHTML = '<p class="empty-state">Nenhuma venda registrada</p>';
        return;
    }
    container.innerHTML = produtos.map((p, i) => `
        <div class="top-product-item">
            <span class="top-rank">#${i + 1}</span>
            <div class="top-info">
                <span class="top-name">${p.nome}</span>
                <span class="top-meta">${p.quantidade || 0} vendidos · ${formatarPreco(p.preco)}</span>
            </div>
            <span class="top-estoque">${p.estoque} em estoque</span>
        </div>
    `).join('');
}

function renderizarPedidosRecentes(pedidos) {
    const container = document.getElementById('recent-orders-list');
    if (!pedidos || pedidos.length === 0) {
        container.innerHTML = '<p class="empty-state">Nenhum pedido ainda</p>';
        return;
    }
    container.innerHTML = pedidos.map(p => `
        <div class="activity-row">
            <span class="activity-dot ${p.status === 'cancelado' ? 'dot-red' : p.status === 'entregue' ? 'dot-green' : 'dot-gold'}"></span>
            <div class="activity-info">
                <p class="activity-title">Pedido #${p.id} — ${p.cliente_nome}</p>
                <p class="activity-meta">${formatarPreco(p.total)} · ${formatarDataHora(p.criado_em)}</p>
            </div>
            ${statusBadge(p.status)}
        </div>
    `).join('');
}

function renderizarUsuariosRecentes(usuarios) {
    const container = document.getElementById('recent-users-list');
    if (!usuarios || usuarios.length === 0) {
        container.innerHTML = '<p class="empty-state">Nenhum usuário ainda</p>';
        return;
    }
    container.innerHTML = usuarios.map(u => `
        <div class="activity-row">
            <span class="activity-dot ${u.admin ? 'dot-violet' : 'dot-gold'}"></span>
            <div class="activity-info">
                <p class="activity-title">${u.nome}</p>
                <p class="activity-meta">${u.email} · ${formatarData(u.criado_em)}</p>
            </div>
            <span class="status-badge ${u.admin ? 'admin-badge' : ''}">${u.admin ? 'Administrador' : 'Cliente'}</span>
        </div>
    `).join('');
}

/* ==========================================
   PRODUTOS
   ========================================== */
let debounceProdutos = null;

async function carregarProdutos() {
    const busca = document.getElementById('busca-produto').value;
    const categoria = document.getElementById('filtro-categoria').value;
    const status = document.getElementById('filtro-status-estoque').value;

    try {
        // Monta a URL com os filtros escolhidos (busca/categoria/status)
        const params = new URLSearchParams();
        if (busca) params.set('busca', busca);
        if (categoria) params.set('categoria', categoria);
        if (status) params.set('status', status);

        const resp = await fetch(API_BASE + 'produtos.php?' + params.toString());
        const dados = await resp.json();
        if (!dados.sucesso) return;

        renderizarTabelaProdutos(dados.produtos);
        atualizarCategorias(dados.categorias);
    } catch (erro) {
        console.error('Erro ao carregar produtos:', erro);
    }
}

function renderizarTabelaProdutos(produtos) {
    const tbody = document.getElementById('tbody-produtos');
    if (produtos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">Nenhum produto encontrado</td></tr>';
        return;
    }
    tbody.innerHTML = produtos.map(p => `
        <tr>
            <td>
                <div class="product-cell">
                    <img src="../assets/img/${p.imagem || 'carrinho.png'}" alt="${p.nome}" class="table-thumb" onerror="this.src='../assets/img/carrinho.png'">
                    <span class="product-cell-name">${p.nome}</span>
                </div>
            </td>
            <td><span class="category-tag">${p.categoria || '-'}</span></td>
            <td class="price-cell">${formatarPreco(p.preco)}</td>
            <td>
                <div class="stock-control-inline">
                    <button class="btn-qty" onclick="alterarEstoque(${p.id}, ${p.estoque - 1})">−</button>
                    <span class="stock-value">${p.estoque}</span>
                    <button class="btn-qty" onclick="alterarEstoque(${p.id}, ${p.estoque + 1})">+</button>
                </div>
            </td>
            <td>${estoqueBadge(p.estoque)}</td>
            <td>
                <div class="actions-cell">
                    <button class="btn-icon" title="Editar" onclick="editarProduto(${p.id}, '${encodeURIComponent(p.nome)}', ${p.preco}, '${encodeURIComponent(p.imagem || '')}', '${encodeURIComponent(p.categoria || '')}', ${p.estoque})">✎</button>
                    <button class="btn-icon btn-icon-danger" title="Excluir" onclick="excluirProduto(${p.id}, '${encodeURIComponent(p.nome)}')">🗑</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function atualizarCategorias(categorias) {
    const select = document.getElementById('filtro-categoria');
    const current = select.value;
    select.innerHTML = '<option value="">Todas as categorias</option>';
    (categorias || []).forEach(c => {
        const opt = document.createElement('option');
        opt.value = c;
        opt.textContent = c;
        if (c === current) opt.selected = true;
        select.appendChild(opt);
    });

    const datalist = document.getElementById('lista-categorias');
    if (datalist) {
        datalist.innerHTML = '';
        (categorias || []).forEach(c => {
            const opt = document.createElement('option');
            opt.value = c;
            datalist.appendChild(opt);
        });
    }
}

async function alterarEstoque(id, novaQtd) {
    if (novaQtd < 0) novaQtd = 0;
    try {
        await fetch(API_BASE + 'produtos.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, estoque: novaQtd })
        });
        carregarProdutos();
    } catch (erro) {
        showToast('Erro ao atualizar estoque', 'error');
    }
}

function editarProduto(id, nome, preco, imagem, categoria, estoque) {
    document.getElementById('modal-produto-titulo').textContent = 'Editar Produto';
    document.getElementById('produto-edit-id').value = id;
    document.getElementById('produto-nome').value = decodeURIComponent(nome);
    document.getElementById('produto-preco').value = preco;
    document.getElementById('produto-estoque').value = estoque;
    document.getElementById('produto-categoria').value = decodeURIComponent(categoria);
    document.getElementById('produto-imagem').value = decodeURIComponent(imagem);
    document.getElementById('modal-produto').classList.add('active');
}

function excluirProduto(id, nome) {
    showConfirm('Excluir Produto', `Tem certeza que deseja excluir "${decodeURIComponent(nome)}"?`, async () => {
        try {
            const resp = await fetch(API_BASE + 'produtos.php', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            });
            const dados = await resp.json();
            if (dados.sucesso) {
                showToast('Produto excluído com sucesso!');
                carregarProdutos();
            } else {
                showToast(dados.mensagem || 'Erro ao excluir', 'error');
            }
        } catch (erro) {
            showToast('Erro ao excluir produto', 'error');
        }
    });
}

function initProdutos() {
    document.getElementById('btn-novo-produto').addEventListener('click', () => {
        document.getElementById('modal-produto-titulo').textContent = 'Novo Produto';
        document.getElementById('form-produto').reset();
        document.getElementById('produto-edit-id').value = '';
        document.getElementById('modal-produto').classList.add('active');
    });

    document.getElementById('form-produto').addEventListener('submit', async (e) => {
        e.preventDefault();
        const editId = document.getElementById('produto-edit-id').value;
        // Coleta os valores digitados no formulário
        const body = {
            nome: document.getElementById('produto-nome').value,
            preco: parseFloat(document.getElementById('produto-preco').value),
            estoque: parseInt(document.getElementById('produto-estoque').value) || 0,
            categoria: document.getElementById('produto-categoria').value,
            imagem: document.getElementById('produto-imagem').value,
        };

        try {
            let resp;
            if (editId) { // se há ID, é edição de produto existente
                body.id = parseInt(editId);
                resp = await fetch(API_BASE + 'produtos.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                });
            } else { // sem ID, é criação de um produto novo
                resp = await fetch(API_BASE + 'produtos.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                });
            }
            const dados = await resp.json();
            if (dados.sucesso) {
                showToast(editId ? 'Produto atualizado!' : 'Produto criado!');
                closeAllModals();
                carregarProdutos();
            } else {
                showToast(dados.mensagem || 'Erro ao salvar', 'error');
            }
        } catch (erro) {
            showToast('Erro de conexão', 'error');
        }
    });

    ['busca-produto', 'filtro-categoria', 'filtro-status-estoque'].forEach(id => {
        document.getElementById(id).addEventListener(id === 'busca-produto' ? 'input' : 'change', () => {
            clearTimeout(debounceProdutos);
            debounceProdutos = setTimeout(carregarProdutos, 300);
        });
    });
}

/* ==========================================
   PEDIDOS
   ========================================== */
let debouncePedidos = null;

async function carregarPedidos() {
    const busca = document.getElementById('busca-pedido').value;
    const status = document.getElementById('filtro-status-pedido').value;

    try {
        const params = new URLSearchParams();
        if (busca) params.set('busca', busca);
        if (status) params.set('status', status);

        const resp = await fetch(API_BASE + 'pedidos_admin.php?' + params.toString());
        const dados = await resp.json();
        if (!dados.sucesso) return;

        document.getElementById('o-total').textContent = dados.resumo.total;
        document.getElementById('o-pendentes').textContent = dados.resumo.pendentes;
        document.getElementById('o-enviados').textContent = dados.resumo.enviados;
        document.getElementById('o-entregues').textContent = dados.resumo.entregues;
        document.getElementById('o-cancelados').textContent = dados.resumo.cancelados;

        renderizarTabelaPedidos(dados.pedidos);
    } catch (erro) {
        console.error('Erro ao carregar pedidos:', erro);
    }
}

function renderizarTabelaPedidos(pedidos) {
    const tbody = document.getElementById('tbody-pedidos');
    if (pedidos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">Nenhum pedido encontrado</td></tr>';
        return;
    }
    tbody.innerHTML = pedidos.map(p => {
        const pagamento = { 'pix': 'Pix', 'credit': 'Crédito', 'debit': 'Débito', 'boleto': 'Boleto' };
        return `
        <tr>
            <td><strong>#${p.id}</strong></td>
            <td>
                <div class="product-cell">
                    <div class="avatar-sm">${p.cliente_nome.charAt(0).toUpperCase()}</div>
                    <div>
                        <span class="product-cell-name">${p.cliente_nome}</span>
                        <span class="product-cell-meta">${p.cliente_email}</span>
                    </div>
                </div>
            </td>
            <td>${p.qtd_itens} itens</td>
            <td class="price-cell">${formatarPreco(p.total)}</td>
            <td><span class="payment-tag">${pagamento[p.forma_pagamento] || p.forma_pagamento}</span></td>
            <td>${statusBadge(p.status)}</td>
            <td>${formatarData(p.criado_em)}</td>
            <td>
                <div class="actions-cell">
                    <select class="status-select" onchange="atualizarStatusPedido(${p.id}, this.value)" data-status="${p.status}">
                        <option value="confirmado" ${p.status === 'confirmado' ? 'selected' : ''}>Pendente</option>
                        <option value="enviado" ${p.status === 'enviado' ? 'selected' : ''}>Enviado</option>
                        <option value="entregue" ${p.status === 'entregue' ? 'selected' : ''}>Entregue</option>
                        <option value="cancelado" ${p.status === 'cancelado' ? 'selected' : ''}>Cancelado</option>
                    </select>
                </div>
            </td>
        </tr>`;
    }).join('');
}

// Altera o status do pedido (confirmado/envio/entrega/cancelamento).
// No cancelamento, o backend devolve o estoque aos produtos.
async function atualizarStatusPedido(id, status) {
    const acao = status === 'cancelado' ? 'cancelar' : 'atualizar';
    // Mostra um modal de confirmação antes de executar a ação
    showConfirm(
        `Confirmar ${acao}`,
        status === 'cancelado'
            ? `Deseja cancelar o pedido #${id}? O estoque será devolvido.`
            : `Alterar status do pedido #${id} para "${status}"?`,
        async () => {
            try {
                const resp = await fetch(API_BASE + 'pedidos_admin.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, status })
                });
                const dados = await resp.json();
                if (dados.sucesso) {
                    showToast('Status atualizado!');
                    carregarPedidos();
                } else {
                    showToast(dados.mensagem || 'Erro ao atualizar', 'error');
                    carregarPedidos();
                }
            } catch (erro) {
                showToast('Erro de conexão', 'error');
                carregarPedidos();
            }
        }
    );
}

function initPedidos() {
    ['busca-pedido', 'filtro-status-pedido'].forEach(id => {
        document.getElementById(id).addEventListener(id === 'busca-pedido' ? 'input' : 'change', () => {
            clearTimeout(debouncePedidos);
            debouncePedidos = setTimeout(carregarPedidos, 300);
        });
    });
}

/* ==========================================
   USUÁRIOS
   ========================================== */
let debounceUsuarios = null;

async function carregarUsuarios() {
    const busca = document.getElementById('busca-usuario').value;
    const role = document.getElementById('filtro-role').value;

    try {
        const params = new URLSearchParams();
        if (busca) params.set('busca', busca);
        if (role) params.set('role', role);

        const resp = await fetch(API_BASE + 'usuarios_admin.php?' + params.toString());
        const dados = await resp.json();
        if (!dados.sucesso) return;

        document.getElementById('u-total').textContent = dados.resumo.total;
        document.getElementById('u-admins').textContent = dados.resumo.admins;
        document.getElementById('u-clientes').textContent = dados.resumo.clientes;

        renderizarTabelaUsuarios(dados.usuarios);
    } catch (erro) {
        console.error('Erro ao carregar usuários:', erro);
    }
}

function renderizarTabelaUsuarios(usuarios) {
    const tbody = document.getElementById('tbody-usuarios');
    if (usuarios.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">Nenhum usuário encontrado</td></tr>';
        return;
    }
    tbody.innerHTML = usuarios.map(u => `
        <tr>
            <td>
                <div class="product-cell">
                    <div class="avatar-sm ${u.admin ? 'avatar-admin' : ''}">${u.nome.charAt(0).toUpperCase()}</div>
                    <span class="product-cell-name">${u.nome}</span>
                </div>
            </td>
            <td>${u.email}</td>
            <td>
<span class="status-badge ${u.admin ? 'admin-badge' : ''}">${u.admin ? 'Administrador' : 'Cliente'}</span>
            </td>
            <td>${u.qtd_pedidos}</td>
            <td class="price-cell">${formatarPreco(u.valor_gasto)}</td>
            <td>${formatarData(u.criado_em)}</td>
            <td>
                <div class="actions-cell">
                    <button class="btn-icon" title="${u.admin ? 'Rebaixar para Cliente' : 'Promover a Administrador'}"
                            onclick="toggleAdmin(${u.id}, ${u.admin ? 0 : 1}, '${encodeURIComponent(u.nome)}')">
                        ${u.admin ? '🔽' : '🔼'}
                    </button>
                    ${u.admin ? '' : `<button class="btn-icon btn-icon-danger" title="Excluir" onclick="excluirUsuario(${u.id}, '${encodeURIComponent(u.nome)}')">🗑</button>`}
                </div>
            </td>
        </tr>
    `).join('');
}

async function toggleAdmin(id, novoAdmin, nome) {
    const acao = novoAdmin ? 'promover a administrador' : 'rebaixar a cliente';
    showConfirm('Confirmar', `Deseja ${acao} "${decodeURIComponent(nome)}"?`, async () => {
        try {
            const resp = await fetch(API_BASE + 'usuarios_admin.php', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, admin: !!novoAdmin })
            });
            const dados = await resp.json();
            if (dados.sucesso) {
                showToast('Usuário atualizado!');
                carregarUsuarios();
            } else {
                showToast(dados.mensagem || 'Erro', 'error');
            }
        } catch (erro) {
            showToast('Erro de conexão', 'error');
        }
    });
}

function excluirUsuario(id, nome) {
    showConfirm('Excluir Usuário', `Tem certeza que deseja excluir "${decodeURIComponent(nome)}"? Todos os dados serão perdidos.`, async () => {
        try {
            const resp = await fetch(API_BASE + 'usuarios_admin.php', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            });
            const dados = await resp.json();
            if (dados.sucesso) {
                showToast('Usuário excluído!');
                carregarUsuarios();
            } else {
                showToast(dados.mensagem || 'Erro', 'error');
            }
        } catch (erro) {
            showToast('Erro de conexão', 'error');
        }
    });
}

function initUsuarios() {
    ['busca-usuario', 'filtro-role'].forEach(id => {
        document.getElementById(id).addEventListener(id === 'busca-usuario' ? 'input' : 'change', () => {
            clearTimeout(debounceUsuarios);
            debounceUsuarios = setTimeout(carregarUsuarios, 300);
        });
    });
}

/* ==========================================
   MODAIS
   ========================================== */
// Configura os modais (formulários de produto, pedido e confirmação)
function initModais() {
    ['modal-produto', 'modal-pedido', 'modal-confirm'].forEach(id => {
        const overlay = document.getElementById(id);
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeAllModals();
        });
    });

    document.getElementById('modal-produto-close').addEventListener('click', closeAllModals);
    document.getElementById('btn-cancelar-produto').addEventListener('click', closeAllModals);
    document.getElementById('modal-pedido-close').addEventListener('click', closeAllModals);
    document.getElementById('modal-confirm-close').addEventListener('click', closeAllModals);

    document.getElementById('btn-confirm-yes').addEventListener('click', () => {
        if (confirmCallback) confirmCallback();
        closeAllModals();
    });
    document.getElementById('btn-confirm-no').addEventListener('click', closeAllModals);
}

/* ==========================================
   INICIALIZAÇÃO
   ========================================== */
(async function init() {
    await protegerPagina();

    const now = new Date();
    const meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    document.getElementById('current-date').textContent = now.getDate() + ' de ' + meses[now.getMonth()] + ' de ' + now.getFullYear();

    initSidebar();
    initProdutos();
    initPedidos();
    initUsuarios();
    initModais();
    carregarDashboard();
})();
