const API_BASE = 'backend/api/';

// ============================================================
// inicio.js — Lógica da página inicial da loja
// Controla: acessibilidade, sessão do usuário, carrinho (mini
// sidebar), detalhes do produto, menu mobile e busca por nome.
// ============================================================

/* ==========================================
   0. ACESSIBILIDADE
   ========================================== */
const accBtn = document.getElementById('acc-toggle');
const accMenu = document.getElementById('acc-menu');
let currentFontSize = 16;

accBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    accMenu.classList.toggle('hidden');
});

// Ajusta o tamanho da fonte (limites 12px e 24px)
function changeFontSize(delta) {
    currentFontSize += delta;
    if (currentFontSize < 12) currentFontSize = 12;
    if (currentFontSize > 24) currentFontSize = 24;
    document.documentElement.style.fontSize = currentFontSize + 'px';
}

// Tema escuro: salva a preferência do usuário no navegador
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
}

function toggleContrast() {
    document.body.classList.toggle('high-contrast');
}

// Volta todas as configurações de acessibilidade ao padrão
function resetAccessibility() {
    currentFontSize = 16;
    document.documentElement.style.fontSize = '16px';
    document.body.classList.remove('dark-mode');
    document.body.classList.remove('high-contrast');
    localStorage.setItem('darkMode', 'false');
}

window.addEventListener('click', (event) => {
    if (!accBtn.contains(event.target) && !accMenu.contains(event.target)) {
        accMenu.classList.add('hidden');
    }
});

if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
}

/* ==========================================
   1. SESSÃO (mostra se o usuário está logado)
   ========================================== */
// Consulta sessao.php para exibir ícone de login ou botão de sair
async function carregarSessao() {
    try {
        const resp = await fetch(API_BASE + 'sessao.php');
        const dados = await resp.json();
        const loginLink = document.getElementById('login-link');
        const logoutBtn = document.getElementById('logout-btn');

        if (dados.logado) {
            loginLink.title = `Olá, ${dados.nome}`;
            loginLink.innerHTML = '👤';
            loginLink.href = '#';
            if (logoutBtn) logoutBtn.style.display = 'inline-flex';
        } else {
            if (logoutBtn) logoutBtn.style.display = 'none';
        }
    } catch (erro) {
        console.warn('Não foi possível verificar a sessão:', erro);
    }
}

async function logout() {
    try {
        await fetch(API_BASE + 'logout.php', { method: 'POST' });
    } catch (e) {}
    window.location.reload();
}

document.getElementById('logout-btn')?.addEventListener('click', logout);

/* ==========================================
   2. CARRINHO (conectado ao backend/banco de dados)
   ========================================== */
const cartCountElement = document.getElementById('cart-count');
const toast = document.getElementById('cart-toast');

function showToast(mensagem) {
    if (mensagem) toast.textContent = mensagem;
    toast.classList.remove('toast-hidden');
    toast.classList.add('toast-visible');
    setTimeout(() => {
        toast.classList.remove('toast-visible');
        toast.classList.add('toast-hidden');
        toast.textContent = 'Adicionado ao carrinho!';
    }, 3000);
}

let atualizarContadorTopo = async function _atualizarContadorTopo() {
    try {
        const resp = await fetch(API_BASE + 'carrinho.php');
        if (resp.status === 401) {
            cartCountElement.innerText = 0;
            return;
        }
        const dados = await resp.json();
        const quantidade = (dados.itens || []).reduce((soma, item) => soma + Number(item.quantidade), 0);
        cartCountElement.innerText = quantidade;
    } catch (erro) {
        console.warn('Não foi possível atualizar o carrinho:', erro);
    }
};

// Adiciona um produto ao carrinho no banco (via API)
async function addToCart(produtoId) {
    try {
        const resp = await fetch(API_BASE + 'carrinho.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ produto_id: produtoId }),
        });

        // 401 = usuário não logado: pede para entrar primeiro
        if (resp.status === 401) {
            if (confirm('Você precisa fazer login para adicionar produtos ao carrinho. Ir para o login?')) {
                window.location.href = 'pages/login.html';
            }
            return;
        }

        const dados = await resp.json();
        if (dados.sucesso) {
            showToast();              // feedback visual de confirmação
            atualizarContadorTopo();  // atualiza o contador do menu
        } else {
            alert(dados.mensagem || 'Não foi possível adicionar o produto ao carrinho.');
        }
    } catch (erro) {
        alert('Erro de conexão ao adicionar o produto. Tente novamente.');
    }
}

/* ==========================================
   3. SIDEBAR DO CARRINHO (mini-preview)
   ========================================== */
const cartSidebar = document.getElementById('cart-sidebar');
const openCartBtn = document.getElementById('open-cart');
const closeCartBtn = document.getElementById('close-cart');
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalElement = document.getElementById('cart-total');
const overlay = document.getElementById('cart-overlay');

openCartBtn.addEventListener('click', (e) => {
    e.preventDefault();
    cartSidebar.classList.add('open');
    overlay.classList.add('show');
    renderCart();
});

[closeCartBtn, overlay].forEach(el => {
    el.addEventListener('click', () => {
        cartSidebar.classList.remove('open');
        overlay.classList.remove('show');
    });
});

async function renderCart() {
    cartItemsContainer.innerHTML = '<p class="empty-msg">Carregando...</p>';

    try {
        const resp = await fetch(API_BASE + 'carrinho.php');

        if (resp.status === 401) {
            cartItemsContainer.innerHTML = '<p class="empty-msg">Faça login para ver seu carrinho.</p>';
            cartTotalElement.innerText = 'R$ 0,00';
            return;
        }

        const dados = await resp.json();
        const itens = dados.itens || [];
        cartItemsContainer.innerHTML = '';
        let total = 0;

        if (itens.length === 0) {
            cartItemsContainer.innerHTML = '<p class="empty-msg">Seu carrinho está vazio.</p>';
        } else {
            itens.forEach((item) => {
                const subtotal = item.preco * item.quantidade;
                total += subtotal;

                const div = document.createElement('div');
                div.classList.add('cart-item');
                div.innerHTML = `
                    <div>
                        <strong>${item.nome}</strong><br>
                        <span>${item.quantidade}x R$ ${Number(item.preco).toFixed(2).replace('.', ',')}</span>
                    </div>
                    <button data-produto-id="${item.produto_id}" class="btn-remover-mini" style="background:none; border:none; cursor:pointer; color:red;">Remover</button>
                `;
                cartItemsContainer.appendChild(div);
            });
        }

        cartTotalElement.innerText = `R$ ${total.toFixed(2).replace('.', ',')}`;
    } catch (erro) {
        cartItemsContainer.innerHTML = '<p class="empty-msg">Erro ao carregar o carrinho.</p>';
    }
}

cartItemsContainer.addEventListener('click', async (e) => {
    if (!e.target.classList.contains('btn-remover-mini')) return;
    const produtoId = e.target.dataset.produtoId;

    await fetch(API_BASE + 'carrinho.php', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ produto_id: Number(produtoId) }),
    });

    renderCart();
    atualizarContadorTopo();
});

const checkoutBtn = document.querySelector('.checkout-btn');
if (checkoutBtn) {
    checkoutBtn.addEventListener('click', () => {
        window.location.href = 'pages/carrinho.html';
    });
}

/* ==========================================
   4. SIDEBAR DE DETALHES DO PRODUTO
   ========================================== */
function openProductDetails(card) {
    const detailsSidebar = document.getElementById('product-details-sidebar');
    const detailsName = document.getElementById('details-product-name');
    const detailsImage = document.getElementById('details-product-image');
    const detailsPrice = document.getElementById('details-product-price');
    const detailsDesc = document.getElementById('details-product-description');
    const detailsAddToCartBtn = document.getElementById('details-add-to-cart');

    const name = card.querySelector('.product-name').innerText;
    const imageSrc = card.querySelector('img').src;
    const price = card.querySelector('.price').innerText;
    const produtoId = Number(card.dataset.produtoId);

    detailsName.innerText = name;
    detailsImage.src = imageSrc;
    detailsPrice.innerText = price;

    if (typeof productDescriptions !== 'undefined') {
        detailsDesc.innerText = productDescriptions[name] || 'Descrição detalhada disponível em breve.';
    }

    detailsAddToCartBtn.onclick = (e) => {
        e.stopPropagation();
        addToCart(produtoId);
    };

    detailsSidebar.classList.add('open');
    overlay.classList.add('show');
}

function ativarCliqueNosProdutos() {
    document.querySelectorAll('.product-card img, .product-card .product-name').forEach(element => {
        element.style.cursor = 'pointer';
        element.addEventListener('click', (e) => {
            if (element.classList.contains('cart-btn-icon')) return;
            const card = element.closest('.product-card');
            openProductDetails(card);
        });
    });

    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            const card = button.closest('.product-card');
            const produtoId = Number(card.dataset.produtoId);
            addToCart(produtoId);
        });
    });
}

/* ==========================================
   5. DROPDOWN DE MARCAS
   ========================================== */
const marcasLink = document.getElementById('marcas-link');
const marcasMenu = document.getElementById('marcas-menu');

marcasLink.addEventListener('click', (e) => {
    e.preventDefault();
    marcasMenu.classList.toggle('hidden');
});

window.addEventListener('click', (e) => {
    if (!marcasLink.contains(e.target)) {
        marcasMenu.classList.add('hidden');
    }
});

function filterByBrand(brand) {
    alert('Você selecionou a marca: ' + brand + '. Em breve listaremos apenas esses produtos!');
    marcasMenu.classList.add('hidden');
}

/* ==========================================
   6. TROCA DE VITRINE POR CATEGORIA
   ========================================== */
function trocarVitrine(event, templateId) {
    event.preventDefault();

    const heroHome = document.querySelector('.hero-section');
    const productsHome = document.querySelector('.products-section');
    const template = document.getElementById(templateId);

    heroHome.classList.add('fade-out');
    productsHome.classList.add('fade-out');

    setTimeout(() => {
        heroHome.style.display = 'none';
        productsHome.innerHTML = '';
        const content = template.content.cloneNode(true);

        const animatedWrapper = document.createElement('div');
        animatedWrapper.classList.add('fade-in-section');
        animatedWrapper.appendChild(content);

        productsHome.appendChild(animatedWrapper);
        productsHome.classList.remove('fade-out');

        ativarCliqueNosProdutos();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 400);
}

function showCabelosPage(event) { trocarVitrine(event, 'cabelos-template'); }
function showPerfumesPage(event) { trocarVitrine(event, 'perfumes-template'); }
function showMakesPage(event) { trocarVitrine(event, 'makes-template'); }
function showCuidadosPage(event) { trocarVitrine(event, 'cuidados-template'); }

/* ==========================================
   7. INICIALIZAÇÃO (script está no final do <body>,
      então o DOM já está pronto)
   ========================================== */
const closeDetailsBtn = document.getElementById('close-details');
const detailsSidebar = document.getElementById('product-details-sidebar');

if (closeDetailsBtn) {
    closeDetailsBtn.addEventListener('click', () => {
        detailsSidebar.classList.remove('open');
        overlay.classList.remove('show');
    });
}

if (overlay) {
    overlay.addEventListener('click', () => {
        detailsSidebar.classList.remove('open');
        if (cartSidebar) cartSidebar.classList.remove('open');
        overlay.classList.remove('show');
    });
}

ativarCliqueNosProdutos();
carregarSessao();
atualizarContadorTopo();

/* ==========================================
   8. MENU MOBILE (HAMBURGUER)
   ========================================== */
const hamburgerBtn = document.getElementById('hamburger-btn');
const mobileMenu = document.getElementById('mobile-menu');
const closeMobileMenu = document.getElementById('close-mobile-menu');
let mobileOverlay = document.createElement('div');
mobileOverlay.classList.add('mobile-overlay');
document.body.appendChild(mobileOverlay);

if (hamburgerBtn && mobileMenu) {
    hamburgerBtn.addEventListener('click', () => {
        hamburgerBtn.classList.toggle('active');
        mobileMenu.classList.toggle('open');
        mobileOverlay.classList.toggle('show');
    });
    closeMobileMenu.addEventListener('click', () => {
        hamburgerBtn.classList.remove('active');
        mobileMenu.classList.remove('open');
        mobileOverlay.classList.remove('show');
    });
    mobileOverlay.addEventListener('click', () => {
        hamburgerBtn.classList.remove('active');
        mobileMenu.classList.remove('open');
        mobileOverlay.classList.remove('show');
    });
}

/* ==========================================
   9. BUSCA DE PRODUTOS
   ========================================== */
const searchInput = document.querySelector('.search-container input');
const searchBtn = document.querySelector('.search-btn');
const productsGrid = document.querySelector('.products-grid');

function filtrarProdutos(termo) {
    if (!productsGrid) return;
    const cards = productsGrid.querySelectorAll('.product-card');
    const termoLower = termo.toLowerCase().trim();

    if (!termoLower) {
        cards.forEach(c => c.classList.remove('search-hidden'));
        productsGrid.classList.remove('searching');
        const msg = productsGrid.querySelector('.no-results-msg');
        if (msg) msg.remove();
        return;
    }

    productsGrid.classList.add('searching');
    let encontrados = 0;

    cards.forEach(card => {
        const nome = (card.querySelector('.product-name')?.textContent || '').toLowerCase();
        if (nome.includes(termoLower)) {
            card.classList.remove('search-hidden');
            encontrados++;
        } else {
            card.classList.add('search-hidden');
        }
    });

    let msgExistente = productsGrid.querySelector('.no-results-msg');
    if (msgExistente) msgExistente.remove();

    if (encontrados === 0) {
        const msg = document.createElement('p');
        msg.classList.add('no-results-msg');
        msg.textContent = `Nenhum produto encontrado para "${termo}"`;
        productsGrid.appendChild(msg);
    }
}

if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        filtrarProdutos(e.target.value);
    });
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            filtrarProdutos(searchInput.value);
        }
    });
}
if (searchBtn) {
    searchBtn.addEventListener('click', () => {
        filtrarProdutos(searchInput.value);
    });
}

/* ==========================================
   10. ANIMAÇÃO DO BADGE DO CARRINHO
   ========================================== */
const originalAtualizarContador = atualizarContadorTopo;
atualizarContadorTopo = async function() {
    const valorAntes = cartCountElement.innerText;
    await originalAtualizarContador();
    if (cartCountElement.innerText !== valorAntes) {
        cartCountElement.classList.remove('bump');
        void cartCountElement.offsetWidth;
        cartCountElement.classList.add('bump');
    }
};
