// ============================================================
// carrinho.js — Página do carrinho de compras
// Lista os itens (vindos do banco via carrinho.php), permite
// aumentar/diminuir quantidade, remover itens e ir para o checkout.
// ============================================================
const API_BASE = '../backend/api/';
const TAXA_ENVIO = 15.00; // frete fixo do projeto

document.addEventListener('DOMContentLoaded', () => {

    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }

    const containerProdutos = document.getElementById('lista-produtos-carrinho');
    const txtSubtotal = document.getElementById('subtotal-valor');
    const txtTotal = document.getElementById('total-valor');
    const btnFinalizar = document.getElementById('btn-finalizar');

    // Formata número como preço em Real (ex.: 1234.5 -> R$ 1.234,50)
    function formatarPreco(valor) {
        return `R$ ${Number(valor).toFixed(2).replace('.', ',')}`;
    }

    // Busca o carrinho do usuário logado na API
    async function buscarCarrinho() {
        const resp = await fetch(API_BASE + 'carrinho.php');

        // Código 401 = não logado: a API exige login para o carrinho
        if (resp.status === 401) {
            containerProdutos.innerHTML =
                '<p class="carrinho-vazio">Você precisa <a href="login.html">fazer login</a> para ver seu carrinho.</p>';
            txtSubtotal.textContent = formatarPreco(0);
            txtTotal.textContent = formatarPreco(0);
            return [];
        }

        const dados = await resp.json();
        return dados.itens || [];
    }

    // Renderiza dinamicamente cada item do carrinho no HTML
    async function renderizarCarrinho() {
        const itens = await buscarCarrinho();
        containerProdutos.innerHTML = '';

        if (itens.length === 0) {
            containerProdutos.innerHTML =
                '<p class="carrinho-vazio">Seu carrinho está vazio atualmente.</p>';
            txtSubtotal.textContent = formatarPreco(0);
            txtTotal.textContent = formatarPreco(0);
            return;
        }

        let subtotal = 0;

        itens.forEach((produto) => {
            const subtotalProduto = produto.preco * produto.quantidade; // total do item
            subtotal += subtotalProduto; // acumula o subtotal geral

            // Cria o card do item via template string
            const divItem = document.createElement('div');
            divItem.classList.add('item-carrinho');

            divItem.innerHTML = `
                <div class="item-info">
                    <h4>${produto.nome}</h4>
                    <p>${formatarPreco(produto.preco)}</p>

                    <button class="btn-remover"
                            data-id="${produto.produto_id}">
                        Remover
                    </button>
                </div>

                <div class="item-controles">
                    <button class="btn-qtd diminuir"
                            data-id="${produto.produto_id}"
                            data-qtd="${produto.quantidade}">
                        -
                    </button>

                    <span>${produto.quantidade}</span>

                    <button class="btn-qtd aumentar"
                            data-id="${produto.produto_id}"
                            data-qtd="${produto.quantidade}">
                        +
                    </button>
                </div>
            `;

            containerProdutos.appendChild(divItem);
        });

        // Atualiza o resumo: subtotal e total (subtotal + frete)
        txtSubtotal.textContent = formatarPreco(subtotal);
        txtTotal.textContent = formatarPreco(subtotal + TAXA_ENVIO);
    }

    // Envia a nova quantidade para a API (método PUT)
    async function atualizarQuantidade(produtoId, novaQuantidade) {
        await fetch(API_BASE + 'carrinho.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ produto_id: produtoId, quantidade: novaQuantidade }),
        });
        renderizarCarrinho(); // recarrega a lista após a mudança
    }

    // Remove um item do carrinho (método DELETE)
    async function removerItem(produtoId) {
        await fetch(API_BASE + 'carrinho.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ produto_id: produtoId }),
        });
        renderizarCarrinho();
    }

    // "Delegação de eventos": um único listener trata os cliques nos botões
    containerProdutos.addEventListener('click', (e) => {
        const produtoId = Number(e.target.dataset.id);
        if (!produtoId) return;

        if (e.target.classList.contains('aumentar')) {
            const qtdAtual = Number(e.target.dataset.qtd);
            atualizarQuantidade(produtoId, qtdAtual + 1);
        } else if (e.target.classList.contains('diminuir')) {
            const qtdAtual = Number(e.target.dataset.qtd);
            atualizarQuantidade(produtoId, qtdAtual - 1);
        } else if (e.target.classList.contains('btn-remover')) {
            removerItem(produtoId);
        }
    });

    // Corrigido: agora leva de verdade para a tela de checkout,
    // em vez de só mostrar um alerta e voltar para o início.
    btnFinalizar.addEventListener('click', async () => {
        const itens = await buscarCarrinho();

        if (itens.length === 0) {
            alert('Seu carrinho está vazio!');
            return;
        }

        window.location.href = 'finalizarcompra.html'; // navega para o checkout
    });

    renderizarCarrinho(); // carrega o carrinho ao abrir a página
});
