// ============================================================
// verificacao.js — Tela de verificação de e-mail (cliente)
// Recebe o código de 6 dígitos enviado ao Gmail (pode cair no
// spam) e confirma via API confirmar_email.php.
// ============================================================
const API_BASE = '../backend/api/';

document.addEventListener('DOMContentLoaded', () => {
    const codeForm = document.getElementById('code-form');
    const codeInput = document.getElementById('code');
    const authBtn = document.querySelector('.auth-btn');
    const authStatus = document.getElementById('auth-status');
    const emailDestino = document.getElementById('email-destino');
    const resendLink = document.getElementById('resend-link');

    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }

    // Exibe o e-mail de destino informado no login (guardado no navegador)
    const emailPendente = localStorage.getItem('emailPendente');
    if (emailPendente) emailDestino.textContent = emailPendente;

    // Busca direto no backend: gera/reenvia o código e, se o e-mail não
    // puder ser entregue (WAMP sem SMTP), devolve o código para a tela.
    // Assim a verificação funciona mesmo sem enviar e-mail real.
    async function carregarCodigoDaSessao() {
        try {
            const resp = await fetch(API_BASE + 'verificar_email.php', { method: 'POST' });
            const dados = await resp.json();
            if (dados.sucesso) {
                if (dados.email) emailDestino.textContent = dados.email;
                if (dados.dev_codigo) {
                    mostrarCodigoTeste(dados.dev_codigo);
                } else {
                    mostrarStatus('Código enviado para ' + (dados.email || emailPendente) + ' (verifique o spam).', 'info');
                }
            }
        } catch (erro) { /* silencioso: usa o que já veio do login */ }
    }

    // Modo desenvolvimento: se o e-mail não foi entregue (WAMP sem SMTP),
    // mostra o código gerado para o fluxo continuar funcionando.
    const devCodigo = localStorage.getItem('devCodigo');
    if (devCodigo) {
        mostrarCodigoTeste(devCodigo);
    }

    function mostrarCodigoTeste(codigo) {
        const existing = document.querySelector('.dev-code-box');
        if (existing) existing.remove();
        const hint = document.createElement('div');
        hint.className = 'dev-code-box';
        hint.style.cssText = 'margin-bottom:16px;padding:12px;border:1px dashed var(--line-soft);border-radius:var(--radius-sm);font-size:.9rem;color:var(--gold);line-height:1.5;';
        hint.innerHTML = '⚠️ Código <strong>não foi enviado ao e-mail</strong> porque falta a SENHA DE APP (SMTP) no arquivo <code>backend/config/mail.php</code>.<br><strong>Código de teste: ' + codigo + '</strong> — use este para entrar. Quando a senha de app for preenchida, o código chegará na caixa de entrada de verdade.';
        codeForm.parentElement.insertBefore(hint, codeForm);
    }
    carregarCodigoDaSessao();

    // Formata o código com espaços (000 000)
    codeInput.addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '').substring(0, 6);
        e.target.value = v;
    });

    // Confirma o código
    codeForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const codigo = codeInput.value;
        if (codigo.length !== 6) {
            mostrarStatus('Digite o código de 6 dígitos recebido por e-mail.', 'error');
            return;
        }

        authBtn.innerHTML = 'Verificando...';
        authBtn.disabled = true;

        try {
            const resp = await fetch(API_BASE + 'confirmar_email.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ codigo, email: emailPendente || '' }),
            });
            const dados = await resp.json();

            if (dados.sucesso) {
                localStorage.removeItem('emailPendente');
                localStorage.removeItem('devCodigo');
                mostrarStatus(dados.mensagem, 'success');
                setTimeout(() => {
                    window.location.href = '../inicio.html';
                }, 1200);
            } else {
                mostrarStatus(dados.mensagem || 'Código inválido.', 'error');
                authBtn.innerHTML = 'Verificar E-mail';
                authBtn.disabled = false;
            }
        } catch (erro) {
            mostrarStatus('Erro de conexão. Verifique se o PHP/MySQL estão rodando.', 'error');
            authBtn.innerHTML = 'Verificar E-mail';
            authBtn.disabled = false;
        }
    });

    // Reenvia o código
    resendLink.addEventListener('click', async (e) => {
        e.preventDefault();
        resendLink.textContent = 'Enviando...';
        try {
            const resp = await fetch(API_BASE + 'verificar_email.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: emailPendente || '' }),
            });
            const dados = await resp.json();
            mostrarStatus(dados.mensagem || 'Código reenviado!', 'info');
        } catch (erro) {
            mostrarStatus('Falha ao reenviar o código.', 'error');
        } finally {
            resendLink.textContent = 'enviar novo código';
        }
    });

    function mostrarStatus(msg, tipo) {
        authStatus.textContent = msg;
        authStatus.style.display = 'block';
        if (tipo === 'error') {
            authStatus.style.color = '#d43d51';
        } else if (tipo === 'success') {
            authStatus.style.color = '#1a8a5c';
        } else {
            authStatus.style.color = 'var(--text-mid)';
        }
    }
});