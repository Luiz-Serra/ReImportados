/* ============================================================
   ajuda.js — Página de ajuda/FAQ
   Implementa:
    * FAQ expansível (pergunta/pergunta aberta)
    * Navegação por categorias com rolagem suave
    * "Scroll spy": destaca a categoria visível na tela
    * Envio de feedback via WhatsApp
   Obs.: usa "event delegation" (um listener no body que captura
   cliques em elementos child), evitando vários listeners soltos.
   ============================================================ */

// FAQ EXPANSÍVEL — event delegation no body
document.body.addEventListener('click', function (e) {
    var btn = e.target.closest('.faq-question');
    if (!btn) return;

    var item = btn.closest('.faq-item');
    if (!item) return;

    var wasOpen = item.classList.contains('open');

    // fecha outros na mesma categoria
    var category = item.closest('.faq-category');
    if (category) {
        var abertos = category.querySelectorAll('.faq-item.open');
        for (var i = 0; i < abertos.length; i++) {
            if (abertos[i] !== item) {
                abertos[i].classList.remove('open');
            }
        }
    }

    if (wasOpen) {
        item.classList.remove('open');
    } else {
        item.classList.add('open');
    }
});

// NAVEGAÇÃO DE CATEGORIAS — event delegation
document.body.addEventListener('click', function (e) {
    var btn = e.target.closest('.cat-btn');
    if (!btn) return;

    var allBtns = document.querySelectorAll('.cat-btn');
    for (var i = 0; i < allBtns.length; i++) {
        allBtns[i].classList.remove('active');
    }
    btn.classList.add('active');

    var targetId = btn.getAttribute('data-target');
    var target = document.getElementById(targetId);
    if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
});

// SCROLL SPY
(function () {
    var catBtns = document.querySelectorAll('.cat-btn');
    var cats = document.querySelectorAll('.faq-category');
    if (!cats.length || !window.IntersectionObserver) return;

    var observer = new IntersectionObserver(function (entries) {
        for (var i = 0; i < entries.length; i++) {
            if (entries[i].isIntersecting) {
                var id = entries[i].target.id;
                for (var j = 0; j < catBtns.length; j++) {
                    if (catBtns[j].getAttribute('data-target') === id) {
                        catBtns[j].classList.add('active');
                    } else {
                        catBtns[j].classList.remove('active');
                    }
                }
            }
        }
    }, { threshold: 0.15 });

    cats.forEach(function (cat) { observer.observe(cat); });
})();

function sendFeedback() {
    var textarea = document.getElementById('feedbackText');
    var text = textarea.value.trim();
    if (!text) {
        alert('Por favor, digite sua mensagem antes de enviar.');
        return;
    }
    var msg = encodeURIComponent('Olá! Tenho uma dúvida/sugestão:\n\n' + text);
    window.open('https://wa.me/5519982953320?text=' + msg, '_blank');
    textarea.value = '';
}
