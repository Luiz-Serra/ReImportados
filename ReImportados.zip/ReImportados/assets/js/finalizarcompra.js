// ============================================================
// finalizarcompra.js — Checkout (finalização da compra)
// Fluxo:
//  1) Mostra o resumo dos itens do carrinho.
//  2) Permite selecionar/editar o endereço de entrega (via API endereco.php).
//  3) Escolhe o método de pagamento (Pix, cartão, boleto).
//  4) Envia o pedido para pedido.php, que grava tudo no banco.
// ============================================================
const API_BASE = '../backend/api/';
const TAXA_ENVIO = 15.00;

document.addEventListener('DOMContentLoaded', async () => {
    // ---- REFERÊNCIAS AOS ELEMENTOS DA PÁGINA ----
    const itemsReview = document.getElementById('items-review');
    const resumoQtdItens = document.getElementById('resumo-qtd-itens');
    const resumoSubtotal = document.getElementById('resumo-subtotal');
    const resumoSubtotal2 = document.getElementById('resumo-subtotal-2');
    const resumoFrete = document.getElementById('resumo-frete');
    const resumoTotal = document.getElementById('resumo-total');
    const btnFinalize = document.querySelector('.btn-finalize-order');
    const btnBack = document.getElementById('btn-back');

    const addressSection = document.getElementById('address-section');
    const addressModal = document.getElementById('address-modal');
    const modalClose = document.getElementById('modal-close');
    const addressForm = document.getElementById('address-form');
    const cpfInput = document.getElementById('cpf');
    const cepInput = document.getElementById('cep');
    const cepStatus = document.getElementById('cep-status');

    const cardSection = document.getElementById('card-form-section');
    const cardNameInput = document.getElementById('card-name');
    const cardNumberInput = document.getElementById('card-number');
    const cardExpiryInput = document.getElementById('card-expiry');
    const cardCvvInput = document.getElementById('card-cvv');
    const cardNumberDisplay = document.getElementById('card-number-display');
    const cardNameDisplay = document.getElementById('card-name-display');
    const cardExpiryDisplay = document.getElementById('card-expiry-display');
    const cardBrandDisplay = document.getElementById('card-brand-display');
    const parcelasRow = document.getElementById('parcelas-row');
    const parcelasSelect = document.getElementById('parcelas');

    let enderecoSelecionado = null;
    let subtotalGlobal = 0;

    // ---- VOLTAR ----
    btnBack.addEventListener('click', () => {
        window.location.href = 'carrinho.html';
    });

    function formatarPreco(valor) {
        return `R$${Number(valor).toFixed(2).replace('.', ',')}`;
    }

    // ---- CARRINHO ----
    async function carregarItens() {
        const resp = await fetch(API_BASE + 'carrinho.php');
        if (resp.status === 401) {
            itemsReview.innerHTML = '<p>Você precisa <a href="login.html">fazer login</a> para finalizar a compra.</p>';
            btnFinalize.disabled = true;
            return [];
        }
        const dados = await resp.json();
        return dados.itens || [];
    }

    function renderizarResumo(itens) {
        itemsReview.innerHTML = '';
        if (itens.length === 0) {
            itemsReview.innerHTML = '<p>Seu carrinho está vazio. <a href="carrinho.html">Voltar ao carrinho</a>.</p>';
            btnFinalize.disabled = true;
            resumoQtdItens.textContent = '0 itens';
            resumoSubtotal.textContent = formatarPreco(0);
            resumoSubtotal2.textContent = formatarPreco(0);
            resumoTotal.textContent = formatarPreco(TAXA_ENVIO);
            subtotalGlobal = 0;
            return;
        }
        let subtotal = 0, totalItens = 0;
        itens.forEach(item => {
            subtotal += item.preco * item.quantidade;
            totalItens += item.quantidade;
            const card = document.createElement('div');
            card.classList.add('item-card');
            card.innerHTML = `
                <img src="../assets/img/${item.imagem}" alt="${item.nome}">
                <p class="item-name">${item.nome}</p>
                <p class="item-price">${formatarPreco(item.preco)}</p>
                <div class="item-qty-control"><span>Qtd: ${item.quantidade}</span></div>`;
            itemsReview.appendChild(card);
        });
        subtotalGlobal = subtotal;
        const total = subtotal + TAXA_ENVIO;
        resumoQtdItens.textContent = `${totalItens} itens`;
        resumoSubtotal.textContent = formatarPreco(subtotal);
        resumoSubtotal2.textContent = formatarPreco(subtotal);
        resumoFrete.textContent = formatarPreco(TAXA_ENVIO);
        resumoTotal.textContent = formatarPreco(total);
    }

    // ---- ENDEREÇO ----
    async function carregarEnderecos() {
        try {
            const resp = await fetch(API_BASE + 'endereco.php');
            if (resp.status === 401) {
                addressSection.innerHTML = '<div class="address-empty">Faça login para informar o endereço.</div>';
                return;
            }
            const dados = await resp.json();
            const enderecos = dados.enderecos || [];
            if (enderecos.length === 0) {
                addressSection.innerHTML = `
                    <div class="address-icon">📍</div>
                    <div class="address-details address-empty">
                        <strong>Nenhum endereço cadastrado</strong><br>
                        <span>Adicione um endereço para entrega</span>
                    </div>
                    <button class="btn-add-address" id="btn-add-address">+ Adicionar</button>`;
                document.getElementById('btn-add-address').addEventListener('click', abrirModal);
                return;
            }
            const padrao = enderecos.find(e => e.padrao == 1) || enderecos[0];
            enderecoSelecionado = padrao;
            const cepFormatado = padrao.cep.replace(/(\d{5})(\d{3})/, '$1-$2');
            addressSection.innerHTML = `
                <div class="address-icon">📍</div>
                <div class="address-details">
                    <strong>${padrao.rua}, ${padrao.numero}</strong>
                    ${padrao.complemento ? ' - ' + padrao.complemento : ''}<br>
                    <span class="address-text">${padrao.bairro ? padrao.bairro + ' - ' : ''}${padrao.cidade}, ${padrao.uf} - ${cepFormatado}</span>
                </div>
                <div class="address-actions">
                    <button class="btn-change-address" id="btn-change-address">Trocar</button>
                </div>`;
            document.getElementById('btn-change-address').addEventListener('click', abrirModalTroca);

            if (enderecos.length > 1) {
                window._listaEnderecos = enderecos;
            }
        } catch (e) {
            addressSection.innerHTML = '<div class="address-empty">Erro ao carregar endereço.</div>';
        }
    }

    function abrirModal() {
        addressForm.reset();
        cepStatus.textContent = '';
        addressModal.classList.add('active');
    }

    function abrirModalTroca() {
        addressForm.reset();
        cepStatus.textContent = '';
        const lista = window._listaEnderecos || [];
        if (lista.length > 0) {
            let html = '<div class="saved-addresses"><h4>Endereços salvos:</h4>';
            lista.forEach(e => {
                const cepF = e.cep.replace(/(\d{5})(\d{3})/, '$1-$2');
                const activeClass = e.id == enderecoSelecionado?.id ? ' selected' : '';
                html += `<div class="saved-address-item${activeClass}" data-id="${e.id}">
                    <strong>${e.rua}, ${e.numero}</strong><br>
                    <span>${e.bairro ? e.bairro + ' - ' : ''}${e.cidade}, ${e.uf} - ${cepF}</span>
                </div>`;
            });
            html += '</div>';
            const formEl = addressForm.parentElement;
            const existing = formEl.querySelector('.saved-addresses');
            if (existing) existing.remove();
            formEl.insertAdjacentHTML('afterbegin', html);

            formEl.querySelectorAll('.saved-address-item').forEach(el => {
                el.addEventListener('click', async () => {
                    const id = el.dataset.id;
                    await fetch(API_BASE + 'endereco.php', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ endereco_id: parseInt(id) }),
                    });
                    addressModal.classList.remove('active');
                    await carregarEnderecos();
                });
            });
        }
        addressModal.classList.add('active');
    }

    modalClose.addEventListener('click', () => addressModal.classList.remove('active'));
    addressModal.addEventListener('click', (e) => {
        if (e.target === addressModal) addressModal.classList.remove('active');
    });

    // ---- CPF (formatação automática 000.000.000-00) ----
    cpfInput.addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '').substring(0, 11);
        if (v.length > 9) v = v.substring(0, 9) + '-' + v.substring(9);
        else if (v.length > 6) v = v.substring(0, 6) + '.' + v.substring(6);
        else if (v.length > 3) v = v.substring(0, 3) + '.' + v.substring(3);
        e.target.value = v;
    });

    // ---- CEP VIA CEP ----
    // Consulta a API pública ViaCEP para preencher endereço automaticamente
    let cepTimeout;
    cepInput.addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '').substring(0, 8);
        if (v.length > 5) v = v.substring(0, 5) + '-' + v.substring(5);
        e.target.value = v;

        // "Debounce": só busca depois que o usuário para de digitar (500ms)
        clearTimeout(cepTimeout);
        if (v.replace(/\D/g, '').length === 8) {
            cepStatus.textContent = 'Buscando...';
            cepStatus.className = 'cep-status loading';
            cepTimeout = setTimeout(() => buscarCEP(v.replace(/\D/g, '')), 500);
        }
    });

    async function buscarCEP(cep) {
        try {
            const resp = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const dados = await resp.json();
            if (dados.erro) {
                cepStatus.textContent = 'CEP não encontrado';
                cepStatus.className = 'cep-status error';
                return;
            }
            // Preenche os campos automaticamente com os dados retornados
            document.getElementById('rua').value = dados.logradouro || '';
            document.getElementById('bairro').value = dados.bairro || '';
            document.getElementById('cidade').value = dados.localidade || '';
            document.getElementById('uf').value = dados.uf || '';
            document.getElementById('numero').focus();
            cepStatus.textContent = 'Endereço encontrado!';
            cepStatus.className = 'cep-status success';
        } catch (e) {
            cepStatus.textContent = 'Erro ao buscar CEP';
            cepStatus.className = 'cep-status error';
        }
    }

    // ---- SALVAR ENDEREÇO ----
    addressForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const dados = {
            cpf: cpfInput.value,
            cep: cepInput.value,
            rua: document.getElementById('rua').value,
            numero: document.getElementById('numero').value,
            complemento: document.getElementById('complemento').value,
            cidade: document.getElementById('cidade').value,
            uf: document.getElementById('uf').value,
            bairro: document.getElementById('bairro').value,
        };
        try {
            const resp = await fetch(API_BASE + 'endereco.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dados),
            });
            const result = await resp.json();
            if (result.sucesso) {
                addressModal.classList.remove('active');
                await carregarEnderecos();
            } else {
                alert(result.mensagem || 'Erro ao salvar endereço.');
            }
        } catch (e) {
            alert('Erro de conexão ao salvar endereço.');
        }
    });

    const pixPanel = document.getElementById('pix-panel');
    const pixKeyText = document.getElementById('pix-key-text');
    const btnCopyPix = document.getElementById('btn-copy-pix');
    const pixStatus = document.getElementById('pix-status');
    const pixQr = document.getElementById('pix-qr');
    const boletoPanel = document.getElementById('boleto-panel');
    const boletoVencimento = document.getElementById('boleto-vencimento');
    const boletoValor = document.getElementById('boleto-valor');
    const boletoNossoNumero = document.getElementById('boleto-nosso-numero');
    const btnDownloadBoleto = document.getElementById('btn-download-boleto');

    // ---- MÉTODO DE PAGAMENTO ----
    document.querySelectorAll('input[name="payment"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
            const val = e.target.value;
            cardSection.style.display = 'none';
            pixPanel.style.display = 'none';
            boletoPanel.style.display = 'none';

            if (val === 'credit' || val === 'debit') {
                cardSection.style.display = 'block';
                parcelasRow.style.display = val === 'credit' ? 'flex' : 'none';
                if (val === 'credit') gerarParcelas();
                else parcelasSelect.innerHTML = '';
            } else if (val === 'pix') {
                pixPanel.style.display = 'block';
                pixStatus.textContent = '';
                gerarCodigoPix();
            } else if (val === 'boleto') {
                boletoPanel.style.display = 'block';
                gerarBoleto();
            }
        });
    });

    // ---- PIX ----
    function gerarCodigoPix() {
        const total = subtotalGlobal + TAXA_ENVIO;
        const chave = 'reimportados@cnpj.com';
        pixKeyText.textContent = chave;
        const txid = 'RE' + Date.now().toString(36).toUpperCase().slice(-8);
        pixQr.innerHTML = `<div class="pix-qr-box">
            <div class="pix-qr-placeholder">
                <span>Chave Pix Copia e Cola</span>
            </div>
            <div class="pix-txid">TXID: <strong>${txid}</strong></div>
            <div class="pix-valor-display">Valor: <strong>${formatarPreco(total)}</strong></div>
        </div>`;
    }

    btnCopyPix.addEventListener('click', () => {
        const chave = pixKeyText.textContent;
        navigator.clipboard.writeText(chave).then(() => {
            pixStatus.textContent = '✓ Chave copiada com sucesso!';
            pixStatus.className = 'pix-status success';
            btnCopyPix.textContent = 'Copiado!';
            setTimeout(() => { btnCopyPix.textContent = 'Copiar'; }, 2500);
        }).catch(() => {
            const temp = document.createElement('textarea');
            temp.value = chave;
            document.body.appendChild(temp);
            temp.select();
            document.execCommand('copy');
            document.body.removeChild(temp);
            pixStatus.textContent = '✓ Chave copiada com sucesso!';
            pixStatus.className = 'pix-status success';
            btnCopyPix.textContent = 'Copiado!';
            setTimeout(() => { btnCopyPix.textContent = 'Copiar'; }, 2500);
        });
    });

    // ---- BOLETO ----
    function gerarBoleto() {
        const total = subtotalGlobal + TAXA_ENVIO;
        const venc = new Date();
        venc.setDate(venc.getDate() + 3);
        const dia = String(venc.getDate()).padStart(2, '0');
        const mes = String(venc.getMonth() + 1).padStart(2, '0');
        const ano = venc.getFullYear();
        boletoVencimento.textContent = `${dia}/${mes}/${ano}`;
        boletoValor.textContent = formatarPreco(total);
        const nossoNum = String(Math.floor(Math.random() * 9000000000) + 1000000000);
        boletoNossoNumero.textContent = nossoNum.slice(0, 10) + '-' + nossoNum.slice(-1);
    }

    btnDownloadBoleto.addEventListener('click', () => {
        const total = subtotalGlobal + TAXA_ENVIO;
        const venc = boletoVencimento.textContent;
        const nosNum = boletoNossoNumero.textContent;
        const htmlBoleto = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Boleto - Rê Importados</title>
<style>
  body{ font-family: Arial, sans-serif; padding: 30px; color: #333; }
  .boleto{ max-width: 700px; margin: 0 auto; border: 2px solid #333; }
  .boleto-topo{ background: #c9a227; color: #fff; padding: 12px 20px; display: flex; justify-content: space-between; font-weight: bold; }
  .boleto-linha-digitavel{ background: #f5f5f5; padding: 12px 20px; font-family: monospace; font-size: 14px; letter-spacing: 1px; border-bottom: 1px solid #ccc; }
  .boleto-campos{ padding: 20px; }
  .boleto-campo{ margin-bottom: 12px; }
  .boleto-campo label{ display: block; font-size: 11px; color: #666; text-transform: uppercase; }
  .boleto-campo span{ font-size: 14px; font-weight: bold; }
  .boleto-footer{ border-top: 2px solid #333; padding: 12px 20px; font-size: 12px; text-align: center; color: #666; }
  @media print{ body{ padding: 0; } }
</style></head><body>
<div class="boleto">
  <div class="boleto-topo">
    <span>Banco do Brasil - 0019</span>
    <span>Boleto de Cobrança</span>
  </div>
  <div class="boleto-linha-digitavel">00190.00009 00000.000000 00000.000000 0 00000000000000</div>
  <div class="boleto-campos">
    <div class="boleto-campo"><label>Beneficiário</label><span>Rê Importados Eireli</span></div>
    <div class="boleto-campo"><label>CNPJ</label><span>00.000.000/0001-00</span></div>
    <div class="boleto-campo"><label>Data de Vencimento</label><span>${venc}</span></div>
    <div class="boleto-campo"><label>Valor do Documento</label><span>${formatarPreco(total)}</span></div>
    <div class="boleto-campo"><label>Nosso Número</label><span>${nosNum}</span></div>
    <div class="boleto-campo"><label>Multa e Juros</label><span>2% ao mês após vencimento</span></div>
  </div>
  <div class="boleto-footer">Pague em qualquer agência bancária, casa lotérica ou internet banking.<br>Este boleto é meramente ilustrativo.</div>
</div>
<script>window.onload=function(){window.print();}</script>
</body></html>`;
        const blob = new Blob([htmlBoleto], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'boleto-reimportados.html';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    });

    // ---- PARCELAS ----
    function gerarParcelas() {
        parcelasSelect.innerHTML = '';
        if (subtotalGlobal <= 0) return;
        const max = 10;
        for (let i = 1; i <= max; i++) {
            const valor = subtotalGlobal / i;
            const texto = `${i}x de ${formatarPreco(valor)}${i === 1 ? ' (à vista)' : ' sem juros'}`;
            const opt = document.createElement('option');
            opt.value = i;
            opt.textContent = texto;
            parcelasSelect.appendChild(opt);
        }
    }

    // ---- PREVIEW DO CARTÃO ----
    cardNameInput.addEventListener('input', () => {
        cardNameDisplay.textContent = cardNameInput.value.toUpperCase() || 'SEU NOME AQUI';
    });

    cardNumberInput.addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '').substring(0, 16);
        let formatted = v.replace(/(.{4})/g, '$1 ').trim();
        e.target.value = formatted;
        cardNumberDisplay.textContent = formatted || '•••• •••• •••• ••••';
        const brand = detectarBandeira(v);
        cardBrandDisplay.textContent = brand;
    });

    cardExpiryInput.addEventListener('input', (e) => {
        let v = e.target.value.replace(/\D/g, '').substring(0, 4);
        if (v.length > 2) v = v.substring(0, 2) + '/' + v.substring(2);
        e.target.value = v;
        cardExpiryDisplay.textContent = v || 'MM/AA';
    });

    // Identifica a bandeira do cartão pelo prefixo do número (regras comuns)
    function detectarBandeira(num) {
        if (/^4/.test(num)) return 'VISA';
        if (/^5[1-5]/.test(num) || /^2[2-7]/.test(num)) return 'MASTERCARD';
        if (/^3[47]/.test(num)) return 'AMEX';
        if (/^6(?:011|5)/.test(num)) return 'ELO';
        return 'CARTÃO';
    }

    // ---- FINALIZAR ----
    // Monta a requisição para pedido.php, que grava o pedido e o
    // endereço no banco e baixa o estoque dos produtos vendidos.
    btnFinalize.addEventListener('click', async () => {
        const metodo = document.querySelector('input[name="payment"]:checked');
        if (!metodo) {
            alert('Selecione um método de pagamento.');
            return;
        }
        // Se o usuário escolheu cartão, valida se preencheu todos os dados
        if ((metodo.value === 'credit' || metodo.value === 'debit') && cardSection.style.display !== 'none') {
            if (!cardNameInput.value || !cardNumberInput.value || !cardExpiryInput.value || !cardCvvInput.value) {
                alert('Preencha todos os dados do cartão.');
                return;
            }
        }

        btnFinalize.disabled = true;
        btnFinalize.textContent = 'Processando...';

        try {
            // Envia o pedido: forma de pagamento + endereço escolhido
            const resp = await fetch(API_BASE + 'pedido.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    forma_pagamento: metodo.value,
                    endereco_id: enderecoSelecionado ? enderecoSelecionado.id : null,
                }),
            });
            const dados = await resp.json();
            if (dados.sucesso) {
                // Mostra a confirmação e volta para a loja
                alert(`Pedido #${dados.pedido_id} confirmado! Total: ${formatarPreco(dados.total)}`);
                window.location.href = '../inicio.html';
            } else {
                alert(dados.mensagem || 'Não foi possível concluir o pedido.');
                btnFinalize.disabled = false;
                btnFinalize.textContent = 'Finalizar Compra';
            }
        } catch (erro) {
            // Problema de conexão com o servidor
            alert('Erro de conexão ao processar o pedido.');
            btnFinalize.disabled = false;
            btnFinalize.textContent = 'Finalizar Compra';
        }
    });

    // ---- INIT ----
    const itens = await carregarItens();
    renderizarResumo(itens);
    await carregarEnderecos();
});
