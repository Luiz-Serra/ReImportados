// ============================================================
// cadastro.js — Lógica da tela de cadastro de novo cliente
// Envia os dados (nome, e-mail, senha) para a API cadastro.php
// e redireciona para o login em caso de sucesso.
// ============================================================
const API_BASE = '../backend/api/';

document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('register-form');
    const authBtn = document.querySelector('.auth-btn');

    // Aplica o tema escuro salvo pelo usuário (acessibilidade)
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // impede o recarregamento da página ao enviar

        // Captura os valores digitados no formulário
        const nome = document.getElementById('fullname').value;
        const email = document.getElementById('email-reg').value;
        const senha = document.getElementById('pass-reg').value;
        const confirmSenha = document.getElementById('pass-confirm').value;

        // Validação no cliente: as senhas precisam ser iguais
        if (senha !== confirmSenha) {
            alert('As senhas não coincidem. Por favor, verifique.');
            return;
        }

        // Feedback visual enquanto a requisição acontece
        authBtn.innerHTML = 'Criando Conta...';
        authBtn.disabled = true;

        try {
            // fetch() é assíncrono: envia os dados como JSON para a API
            const resp = await fetch(API_BASE + 'cadastro.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, email, senha }),
            });

            const dados = await resp.json();

            if (dados.sucesso) {
                alert('Conta criada com sucesso! Agora você pode fazer login.');
                window.location.href = 'login.html'; // leva o usuário para o login
            } else {
                alert(dados.mensagem || 'Não foi possível concluir o cadastro.');
                authBtn.innerHTML = 'Criar Minha Conta';
                authBtn.disabled = false;
            }
        } catch (erro) {
            // Rede fora do ar ou servidor indisponível
            alert('Erro de conexão com o servidor. Verifique se o PHP/MySQL estão rodando.');
            authBtn.innerHTML = 'Criar Minha Conta';
            authBtn.disabled = false;
        }
    });
});
