// ============================================================
// login.js — Lógica da tela de login
// Envia e-mail e senha para login.php. Em caso de sucesso,
// redireciona: admin -> painel; cliente -> página inicial.
// ============================================================
const API_BASE = '../backend/api/';

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const authBtn = document.querySelector('.auth-btn');

    // Aplica o tema escuro salvo pelo usuário (acessibilidade)
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // impede o recarregamento da página

        const email = document.getElementById('email').value;
        const senha = document.getElementById('password').value;

        if (!email || !senha) return; // validação rápida no cliente

        // Feedback visual enquanto a API responde
        authBtn.innerHTML = 'Acessando...';
        authBtn.style.opacity = '0.7';
        authBtn.disabled = true;

        try {
            // Envia as credenciais para a API de login
            const resp = await fetch(API_BASE + 'login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, senha }),
            });

            const dados = await resp.json();

            if (dados.sucesso) {
                // Cliente: precisa confirmar o código de verificação enviado ao e-mail
                if (dados.precisa_verificacao) {
                    localStorage.setItem('emailPendente', dados.email || email);
                    if (dados.dev_codigo) {
                        localStorage.setItem('devCodigo', dados.dev_codigo);
                    }
                    window.location.href = 'verificacao.html';
                    return;
                }

                // A API informa se o usuário é admin para decidir o destino
                if (dados.admin) {
                    window.location.href = 'estoqueadmin.html'; // admin -> painel
                } else {
                    window.location.href = '../inicio.html'; // cliente -> loja
                }
            } else {
                alert(dados.mensagem || 'E-mail ou senha inválidos.');
                authBtn.innerHTML = 'Entrar';
                authBtn.style.opacity = '1';
                authBtn.disabled = false;
            }
        } catch (erro) {
            // Servidor fora do ar ou problema de rede
            alert('Erro de conexão com o servidor. Verifique se o PHP/MySQL estão rodando.');
            authBtn.innerHTML = 'Entrar';
            authBtn.style.opacity = '1';
            authBtn.disabled = false;
        }
    });

    const forgotPwLink = document.querySelector('.forgot-password');
    // "Esqueci a senha": valida se há e-mail informado e avisa o usuário (simulação)
    forgotPwLink.addEventListener('click', (e) => {
        e.preventDefault();
        const userEmail = document.getElementById('email').value;

        if (!userEmail) {
            alert('Por favor, digite seu e-mail no campo acima para recuperar a senha.');
        } else {
            alert(`Um link de recuperação foi enviado para: ${userEmail}`);
        }
    });
});
