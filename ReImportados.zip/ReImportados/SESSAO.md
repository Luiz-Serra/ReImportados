# ReImportados - Sessão de Correções (17/08/2026)

## Correções aplicadas

### 1. backend/config/conexao.php
- `$banco = 'schema'` → `$banco = 're_importados'`

### 2. backend/database/schema.sql
- Hash `$2b$` → `$2y$` (compatibilidade com password_hash/password_verify do PHP)
- Campo `notas TEXT` adicionado à tabela `pedidos`
- 8 novos produtos adicionados (IDs 11-18: Perfumes, Makes, Cuidados Pessoais)

### 3. inicio.html
- Removido `<script>` duplicado no `<head>`
- Removidos `</div>` extras e `<div>` duplicado
- Botão de logout (`🚪`) adicionado ao header (aparece só quando logado)
- Seções de Perfumes, Makes, Cuidados Pessoais movidas para `<template>` elements
- Links do navbar desktop e mobile atualizados com `onclick` pra cada categoria
- Todos os caminhos hardcoded `/ReImportados/` removidos

### 4. assets/js/inicio.js
- Removido wrapper `DOMContentLoaded`
- `carregarSessao()` atualizada: mostra/esconde botão de logout
- Função `logout()` adicionada
- Refatorado `showCabelosPage` → `trocarVitrine(event, templateId)` (função base)
- Funções `showPerfumesPage`, `showMakesPage`, `showCuidadosPage` adicionadas
- API_BASE e links corrigidos (sem `/ReImportados/`)

### 5. assets/css/inicio.css
- Botão de logout estilizado (`.logout-btn`)
- Removido efeito `::before` gradiente dos product cards (glow no mouse)

### 6. assets/js/fx.js
- Removido `.product-card` do seletor do `pointermove` (sem mais glow nos cards)

### 7. Admin Panel — Rebuild Completo

#### Backend APIs:
- `backend/api/dashboard.php` — Estatísticas do dashboard
- `backend/api/produtos.php` — CRUD completo de produtos
- `backend/api/pedidos_admin.php` — Gerenciamento de pedidos
- `backend/api/usuarios_admin.php` — Gerenciamento de usuários
- Todas as APIs: `exit;` adicionado após `echo json_encode()`
- Auth check removido de todas as APIs admin (acesso livre para desenvolvimento)

#### Frontend reconstruído:
- `pages/estoqueadmin.html` — Layout profissional com sidebar, 4 seções
- `assets/js/estoqueadmin.js` — Navegação, CRUD, gráficos Chart.js, filtros, modais
- `assets/css/estoqueadmin.css` — Design system escuro profissional

### 8. Correções gerais (paths)
- `<base href="../">` adicionado em todas as 6 páginas em `pages/`
- Todos os caminhos `/ReImportados/` removidos de 8 JS e 7 HTML
- Login admin automático removido (acesso livre ao painel)

### 9. Botão de acesso admin no login
- `pages/login.html` — Botão "Painel Admin" com link direto ao estoqueadmin
- `assets/css/login.css` — Estilo do botão (borda tracejada sutil)

## Para rodar no WAMP
1. Copiar pasta `ReImportados` para `C:\wamp64\www\`
2. phpMyAdmin → importar `backend/database/schema.sql`
3. Acessar `http://localhost/ReImportados/inicio.html`
4. Login admin: `admin@reimportados.com` / `admin123`
5. Painel admin: botão "Painel Admin" no login.html ou direto em `pages/estoqueadmin.html`

## Se o login admin não funcionar (hash inválido):
```sql
-- Gere o hash em PHP primeiro:
-- <?php echo password_hash('admin123', PASSWORD_DEFAULT); ?>
-- Depois execute:
UPDATE usuarios SET senha = 'NOVO_HASH_AQUI' WHERE email = 'admin@reimportados.com';
```
